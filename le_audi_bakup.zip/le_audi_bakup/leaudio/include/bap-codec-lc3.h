// #pragma once
// #include <stdint.h>
// #include <stddef.h>

// #define LEAUDIO_MAX_CHANNELS 2
// struct lc3_codec;

// struct lc3_codec *lc3_codec_create(
//         int samplerate,
//         int channels,
//         int frame_us,
//         int framelen);

// void lc3_codec_destroy(struct lc3_codec *c);

// int lc3_codec_encode(
//         struct lc3_codec *c,
//         const int32_t *pcm,
//         size_t pcm_bytes,
//         uint8_t *out,
//         size_t out_size,
//         size_t *out_bytes);

// int lc3_codec_decode(
//         struct lc3_codec *c,
//         const uint8_t *in,
//         size_t in_size,
//         int32_t *pcm,
//         size_t pcm_size,
//         size_t *pcm_bytes);

// int lc3_codec_plc(
//         struct lc3_codec *c,
//         int32_t *pcm,
//         size_t pcm_size);

// /* Accessors for opaque lc3_codec */
// size_t bap_lc3_get_frame_samples(struct lc3_codec *c);
// int    bap_lc3_get_channels(struct lc3_codec *c);
// size_t bap_lc3_get_pcm_bytes(struct lc3_codec *c);
// size_t bap_lc3_get_octets_per_frame(struct lc3_codec *c);



#ifndef BAP_CODEC_LC3_H
#define BAP_CODEC_LC3_H

#include <stdint.h>
#include <stddef.h>

#define LEAUDIO_MAX_CHANNELS 2

struct lc3_codec;

struct lc3_codec *lc3_codec_create(
        int samplerate,
        int channels,
        int frame_us,
        int framelen);

struct lc3_codec *lc3_codec_create_from_cc(
        const uint8_t *cc,
        size_t cc_len,
        int samplerate,
        int channels);

void lc3_codec_destroy(struct lc3_codec *c);

/* -------- S16 PCM API (THIS WAS THE BUG) -------- */

int lc3_codec_encode(
        struct lc3_codec *c,
        const int16_t *pcm,
        size_t pcm_bytes,
        uint8_t *out,
        size_t out_size,
        size_t *out_bytes);

int lc3_codec_decode(
        struct lc3_codec *c,
        const uint8_t *in,
        size_t in_size,
        int16_t *pcm,
        size_t pcm_size,
        size_t *pcm_bytes);

int lc3_codec_plc(
        struct lc3_codec *c,
        int16_t *pcm,
        size_t pcm_size);

/* -------- Accessors -------- */

size_t bap_lc3_get_frame_samples(struct lc3_codec *c);
size_t bap_lc3_get_pcm_bytes(struct lc3_codec *c);
size_t bap_lc3_get_octets_per_frame(struct lc3_codec *c);
int bap_lc3_get_channels(struct lc3_codec *c);

#endif
