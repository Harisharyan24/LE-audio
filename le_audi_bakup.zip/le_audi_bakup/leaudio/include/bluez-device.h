#pragma once

#include <gio/gio.h>

/* Initialize BlueZ device monitoring */
int bluez_device_init(GDBusConnection *bus);

/* Cleanup (optional for now) */
void bluez_device_cleanup(void);

// void register_le_audio_endpoints(GDBusConnection *conn);
