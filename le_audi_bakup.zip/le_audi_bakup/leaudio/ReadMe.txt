 ./leaudiod 
 1723  rm leaudiod 
 1724  gcc -std=gnu99 -Wall -Wextra -O0 -g -Iinclude src/main.c src/bluez5-device.c src/bluez-media-endpoint.c src/bluez5-dbus.c src/bap-codec-lc3.c src/iso-io.c -llc3 `pkg-config --cflags --libs gio-2.0 glib-2.0` -o leaudiod




gcc -std=gnu99 -Wall -Wextra -O0 -g \
    -Iinclude \
    src/main.c \
    src/bluez5-device.c \
    src/bluez-media-endpoint.c \
    src/bluez5-dbus.c \
    src/bap-codec-lc3.c \
    src/iso-io.c \
    -llc3 \
    `pkg-config --cflags --libs gio-2.0 glib-2.0` \
    -o leaudiod
