// // // // // // ////////////segmentation fault in bluez///////////////////

// // // // #include "bluez-media-endpoint.h"
// // // // #include <gio/gio.h>
// // // // #include <string.h>
// // // // #include <stdint.h>

// // // // /* Endpoint object paths */
// // // // #define EP_PATH_SOURCE "/local/endpoint/ep0"
// // // // #define EP_PATH_SINK   "/local/endpoint/ep1"

// // // // /* ---------------------------------------------------- */
// // // // /* Endpoint runtime state (per endpoint)                */
// // // // /* ---------------------------------------------------- */

// // // // struct endpoint_ctx {
// // // //     const char *path;
// // // //     char *transport_path;

// // // //     GVariant *codec_config;
// // // //     GVariant *qos;
// // // // };

// // // // static struct endpoint_ctx ep_source = {
// // // //     .path = EP_PATH_SOURCE,
// // // // };

// // // // static struct endpoint_ctx ep_sink = {
// // // //     .path = EP_PATH_SINK,
// // // // };

// // // // /* ---------------------------------------------------- */
// // // // /* Forward declarations                                 */
// // // // /* ---------------------------------------------------- */

// // // // static void handle_select_properties(GDBusMethodInvocation *invocation,
// // // //                                      GVariant *parameters,
// // // //                                      struct endpoint_ctx *ctx);

// // // // static void handle_set_configuration(GDBusMethodInvocation *invocation,
// // // //                                      GVariant *parameters,
// // // //                                      struct endpoint_ctx *ctx);

// // // // // static void handle_clear_configuration(GDBusMethodInvocation *invocation,
// // // // //                                        GVariant *parameters,
// // // // //                                        struct endpoint_ctx *ctx);
// // // // static void handle_clear_configuration(GDBusMethodInvocation *invocation,
// // // //                                        struct endpoint_ctx *ctx);

// // // // static void handle_release(GDBusMethodInvocation *invocation,
// // // //                            struct endpoint_ctx *ctx);

// // // // /* ---------------------------------------------------- */
// // // // /* MediaEndpoint1 introspection XML                     */
// // // // /* ---------------------------------------------------- */

// // // // static const char endpoint_xml[] =
// // // // "<node>"
// // // // " <interface name='org.bluez.MediaEndpoint1'>"
// // // // "  <method name='SelectProperties'>"
// // // // "   <arg name='caps' type='a{sv}' direction='in'/>"
// // // // "   <arg name='properties' type='a{sv}' direction='out'/>"
// // // // "  </method>"
// // // // "  <method name='SetConfiguration'>"
// // // // "   <arg name='transport' type='o' direction='in'/>"
// // // // "   <arg name='properties' type='a{sv}' direction='in'/>"
// // // // "  </method>"
// // // // "  <method name='ClearConfiguration'>"
// // // // "   <arg name='transport' type='o' direction='in'/>"
// // // // "  </method>"
// // // // "  <method name='Release'/>"
// // // // " </interface>"
// // // // "</node>";

// // // // /* ---------------------------------------------------- */
// // // // /* SelectProperties (ALREADY WORKING – DO NOT TOUCH)    */
// // // // /* ---------------------------------------------------- */
// // // // static void handle_select_properties(GDBusMethodInvocation *invocation,
// // // //                                      GVariant *parameters,
// // // //                                      struct endpoint_ctx *ctx)
// // // // {
// // // //     GVariant *caps;
// // // //     g_variant_get(parameters, "(@a{sv})", &caps);

// // // //     g_message("[Endpoint %s] SelectProperties", ctx->path);

// // // //     /* LC3: 48 kHz, 10 ms, mono */
// // // //     static const uint8_t lc3_config[] = {
// // // //         0x02, 0x01, 0x80,        /* Sampling Frequency = 48 kHz */
// // // //         0x02, 0x02, 0x02,        /* Frame Duration = 10 ms */
// // // //         0x02, 0x03, 0x01,        /* Channel Count = 1 */
// // // //         0x03, 0x04, 0x78, 0x00   /* Frame Length = 120 bytes (safe MIN) */
// // // //     };

// // // //     GVariantBuilder props;
// // // //     g_variant_builder_init(&props, G_VARIANT_TYPE("a{sv}"));

// // // //     g_variant_builder_add(&props, "{sv}",
// // // //         "Codec", g_variant_new_byte(0x06)); /* LC3 */

// // // //     g_variant_builder_add(&props, "{sv}",
// // // //         "CodecConfiguration",
// // // //         g_variant_new_fixed_array(G_VARIANT_TYPE_BYTE,
// // // //                                   lc3_config,
// // // //                                   sizeof(lc3_config),
// // // //                                   sizeof(uint8_t)));

// // // //     /* Mono audio location */
// // // //     g_variant_builder_add(&props, "{sv}",
// // // //         "AudioLocations", g_variant_new_uint32(0x00000001));

// // // //     /* Context = Media */
     
// // // //     guint16 context = 0x0001;
// // // //      g_variant_builder_add(&props, "{sv}",
// // // //          "Context",
// // // //          g_variant_new_fixed_array(G_VARIANT_TYPE_UINT16,
// // // //                                    &context, 1, sizeof(guint16)));

// // // //  /* ---------------- Metadata (REQUIRED for Nordic) ---------------- */

// // // //     GVariantBuilder metadata;
// // // //     g_variant_builder_init(&metadata, G_VARIANT_TYPE("ay"));

// // // //     /* LTV:
// // // //      * len=2, type=0x01 (Context Type), value=0x0001 (Media)
// // // //      */
// // // //     const uint8_t meta[] = { 0x02, 0x01, 0x01, 0x00 };

// // // //     for (size_t i = 0; i < sizeof(meta); i++)
// // // //         g_variant_builder_add(&metadata, "y", meta[i]);

// // // //     g_variant_builder_add(&props, "{sv}",
// // // //         "Metadata", g_variant_builder_end(&metadata));


// // // //     /* QoS — aligned with Zephyr defaults */
// // // //     GVariantBuilder qos;
// // // //     g_variant_builder_init(&qos, G_VARIANT_TYPE("a{sv}"));

// // // //     g_variant_builder_add(&qos, "{sv}", "Framing", g_variant_new_byte(0));
// // // //     g_variant_builder_add(&qos, "{sv}", "PHY", g_variant_new_byte(2)); /* 1M */
// // // //     g_variant_builder_add(&qos, "{sv}", "SDU", g_variant_new_uint16(120));
  

    
    
// // // //     g_variant_builder_add(&qos, "{sv}", "Retransmissions", g_variant_new_byte(2));
// // // //     g_variant_builder_add(&qos, "{sv}", "Latency", g_variant_new_uint16(20));
    
// // // //     g_variant_builder_add(&qos, "{sv}", "TargetLatency", g_variant_new_byte(1));
    

// // // //     g_variant_builder_add(&props, "{sv}",
// // // //         "QoS", g_variant_builder_end(&qos));

// // // //     g_dbus_method_invocation_return_value(
// // // //         invocation,
// // // //         g_variant_new("(@a{sv})", g_variant_builder_end(&props)));

// // // //     g_variant_unref(caps);
// // // // }



// // // // /* ---------------------------------------------------- */
// // // // /* SetConfiguration – MAIN WORK STARTS HERE              */
// // // // /* ---------------------------------------------------- */


// // // // // static void handle_set_configuration(GDBusMethodInvocation *invocation,
// // // // //                                      GVariant *parameters,
// // // // //                                      struct endpoint_ctx *ctx)
// // // // // {
// // // // //     const char *transport = NULL;
// // // // //     GVariant *props = NULL;
// // // // //     g_variant_get(parameters, "(&o@a{sv})", &transport, &props);

// // // // //     g_message("[Endpoint %s] SetConfiguration transport=%s", ctx->path, transport);

// // // // //     g_clear_pointer(&ctx->transport_path, g_free);
// // // // //     ctx->transport_path = g_strdup(transport);

// // // // //     g_clear_pointer(&ctx->codec_config, g_variant_unref);
// // // // //     g_clear_pointer(&ctx->qos, g_variant_unref);

// // // // //     GVariant *tmp;

// // // // //     if (g_variant_lookup(props, "CodecConfiguration", "@ay", &tmp))
// // // // //         ctx->codec_config = g_variant_ref(tmp);  // REF before storing

// // // // //     if (g_variant_lookup(props, "QoS", "@a{sv}", &tmp))
// // // // //         ctx->qos = g_variant_ref(tmp);          // REF before storing

// // // // //     g_dbus_method_invocation_return_value(invocation, NULL);
// // // // //     g_variant_unref(props);
// // // // // }


// // // // // static void handle_set_configuration(GDBusMethodInvocation *invocation,
// // // // //                                      GVariant *parameters,
// // // // //                                      struct endpoint_ctx *ctx)
// // // // // {
// // // // //     const char *transport = NULL;
// // // // //     GVariant *props = NULL;

// // // // //     /* Signature: (object-path, dict<string,variant>) */
// // // // //     g_variant_get(parameters, "(&o@a{sv})", &transport, &props);

// // // // //     g_message("[Endpoint %s] SetConfiguration", ctx->path);
// // // // //     g_message("  Transport: %s", transport);

// // // // //     /* Save transport path */
// // // // //     g_clear_pointer(&ctx->transport_path, g_free);
// // // // //     ctx->transport_path = g_strdup(transport);

// // // // //     /* -------- CodecConfiguration -------- */
// // // // //     g_clear_pointer(&ctx->codec_config, g_variant_unref);

// // // // //     if (g_variant_lookup(props, "CodecConfiguration", "@ay",
// // // // //                           &ctx->codec_config)) {
// // // // //         g_message("  CodecConfiguration received (%zu bytes)",
// // // // //                   g_variant_n_children(ctx->codec_config));
// // // // //     } else {
// // // // //         g_warning("  CodecConfiguration missing (still accepting)");
// // // // //     }

// // // // //     /* -------- QoS (opaque, DO NOT PARSE) -------- */
// // // // //     g_clear_pointer(&ctx->qos, g_variant_unref);

// // // // //     if (g_variant_lookup(props, "QoS", "@a{sv}", &ctx->qos)) {
// // // // //         g_message("  QoS received (opaque)");
// // // // //     } else {
// // // // //         g_warning("  QoS missing (still accepting)");
// // // // //     }

// // // // //     /* VERY IMPORTANT:
// // // // //      * Do NOT validate
// // // // //      * Do NOT reject
// // // // //      * Do NOT modify
// // // // //      */
// // // // //     g_dbus_method_invocation_return_value(invocation, NULL);

// // // // //     g_variant_unref(props);
// // // // // }


// // // // static void handle_set_configuration(GDBusMethodInvocation *invocation,
// // // //                                      GVariant *parameters,
// // // //                                      struct endpoint_ctx *ctx)
// // // // {
// // // //     const char *transport = NULL;
// // // //     GVariant *props = NULL;

// // // //     g_variant_get(parameters, "(&o@a{sv})", &transport, &props);

// // // //     g_message("[Endpoint %s] SetConfiguration", ctx->path);
// // // //     g_message("  Transport: %s", transport);
// // // //     g_message("  Properties: %s", g_variant_print(props, TRUE));

// // // //     /* Save transport path */
// // // //     g_free(ctx->transport_path);
// // // //     ctx->transport_path = g_strdup(transport);

// // // //     /* Extract CodecConfiguration */
// // // //     if (ctx->codec_config)
// // // //         g_variant_unref(ctx->codec_config);

// // // //     g_variant_lookup(props, "CodecConfiguration", "@ay", &ctx->codec_config);

// // // //     if (ctx->codec_config)
// // // //         g_message("  CodecConfiguration stored");

// // // //     /* Extract QoS */
// // // //     if (ctx->qos)
// // // //         g_variant_unref(ctx->qos);

// // // //     g_variant_lookup(props, "QoS", "@a{sv}", &ctx->qos);

// // // //     if (ctx->qos)
// // // //         g_message("  QoS stored: %s", g_variant_print(ctx->qos, TRUE));

// // // //     /* IMPORTANT: tell BlueZ we ACCEPT the configuration */
// // // //     g_dbus_method_invocation_return_value(invocation, NULL);

// // // //     g_variant_unref(props);
// // // // }

// // // // /* ---------------------------------------------------- */
// // // // /* ClearConfiguration                                   */
// // // // /* ---------------------------------------------------- */

// // // // // static void handle_clear_configuration(GDBusMethodInvocation *invocation,
// // // // //                                        GVariant *parameters,
// // // // //                                        struct endpoint_ctx *ctx)
// // // // // {
// // // // //     const char *transport;
// // // // //     g_variant_get(parameters, "(&o)", &transport);

// // // // //     g_message("[Endpoint %s] ClearConfiguration transport=%s",
// // // // //               ctx->path, transport);

// // // // //     if (ctx->transport_path &&
// // // // //         g_strcmp0(ctx->transport_path, transport) == 0) {
// // // // //         g_free(ctx->transport_path);
// // // // //         ctx->transport_path = NULL;
// // // // //     }

// // // // //     g_clear_pointer(&ctx->codec_config, g_variant_unref);
// // // // //     g_clear_pointer(&ctx->qos, g_variant_unref);

// // // // //     g_dbus_method_invocation_return_value(invocation, NULL);
// // // // // }




// // // // static void handle_clear_configuration(GDBusMethodInvocation *invocation,
// // // //                                        struct endpoint_ctx *ctx)
// // // // {
// // // //     g_message("[Endpoint %s] ClearConfiguration", ctx->path);

// // // //     g_clear_pointer(&ctx->transport_path, g_free);
// // // //     g_clear_pointer(&ctx->codec_config, g_variant_unref);
// // // //     g_clear_pointer(&ctx->qos, g_variant_unref);

// // // //     g_dbus_method_invocation_return_value(invocation, NULL);
// // // // }




// // // // /* ---------------------------------------------------- */
// // // // /* Release                                              */
// // // // /* ---------------------------------------------------- */

// // // // static void handle_release(GDBusMethodInvocation *invocation,
// // // //                            struct endpoint_ctx *ctx)
// // // // {
// // // //     g_message("[Endpoint %s] Release", ctx->path);

// // // //     g_clear_pointer(&ctx->transport_path, g_free);
// // // //     g_clear_pointer(&ctx->codec_config, g_variant_unref);
// // // //     g_clear_pointer(&ctx->qos, g_variant_unref);

// // // //     g_dbus_method_invocation_return_value(invocation, NULL);
// // // // }

// // // // // static void handle_release(GDBusMethodInvocation *invocation,
// // // // //                            struct endpoint_ctx *ctx)
// // // // // {
// // // // //     g_message("[Endpoint %s] Release", ctx->path);
// // // // //     g_dbus_method_invocation_return_value(invocation, NULL);
// // // // // }


// // // // /* ---------------------------------------------------- */
// // // // /* Method dispatcher (FIXED routing!)                   */
// // // // /* ---------------------------------------------------- */

// // // // static void method_call_cb(GDBusConnection *conn,
// // // //                            const char *sender,
// // // //                            const char *path,
// // // //                            const char *iface,
// // // //                            const char *method,
// // // //                            GVariant *params,
// // // //                            GDBusMethodInvocation *inv,
// // // //                            void *userdata)
// // // // {
// // // //     (void)conn;
// // // //      (void)sender;
// // // //      (void)path;
// // // //      (void)iface;
// // // //      (void)userdata;
// // // //     struct endpoint_ctx *ctx = NULL;

// // // //     if (g_strcmp0(path, EP_PATH_SOURCE) == 0)
// // // //         ctx = &ep_source;
// // // //     else if (g_strcmp0(path, EP_PATH_SINK) == 0)
// // // //         ctx = &ep_sink;
// // // //     else {
// // // //         g_dbus_method_invocation_return_error(
// // // //             inv, G_DBUS_ERROR, G_DBUS_ERROR_FAILED,
// // // //             "Unknown endpoint path");
// // // //         return;
// // // //     }

// // // //     if (g_strcmp0(method, "SelectProperties") == 0)
// // // //         handle_select_properties(inv, params, ctx);
// // // //     else if (g_strcmp0(method, "SetConfiguration") == 0)
// // // //         handle_set_configuration(inv, params, ctx);
// // // //     else if (g_strcmp0(method, "ClearConfiguration") == 0)
// // // //         handle_clear_configuration(inv, ctx);
// // // //     else if (g_strcmp0(method, "Release") == 0)
// // // //         handle_release(inv,ctx);
// // // //     else
// // // //         g_dbus_method_invocation_return_error(
// // // //             inv, G_DBUS_ERROR, G_DBUS_ERROR_UNKNOWN_METHOD,
// // // //             "Unknown method %s", method);
// // // // }

// // // // /* ---------------------------------------------------- */
// // // // /* Export endpoints                                     */
// // // // /* ---------------------------------------------------- */

// // // // int media_endpoint_export(GDBusConnection *conn)
// // // // {
// // // //     GDBusNodeInfo *node;
// // // //     GError *err = NULL;

// // // //     node = g_dbus_node_info_new_for_xml(endpoint_xml, &err);
// // // //     if (!node) {
// // // //         g_printerr("XML parse error: %s\n", err->message);
// // // //         g_error_free(err);
// // // //         return -1;
// // // //     }

// // // //     if (!g_dbus_connection_register_object(
// // // //             conn, EP_PATH_SOURCE,
// // // //             node->interfaces[0],
// // // //             &(GDBusInterfaceVTable){ .method_call = method_call_cb },
// // // //             NULL, NULL, &err)) {
// // // //         g_printerr("Failed to export source endpoint: %s\n", err->message);
// // // //         return -1;
// // // //     }

// // // //     if (!g_dbus_connection_register_object(
// // // //             conn, EP_PATH_SINK,
// // // //             node->interfaces[0],
// // // //             &(GDBusInterfaceVTable){ .method_call = method_call_cb },
// // // //             NULL, NULL, &err)) {
// // // //         g_printerr("Failed to export sink endpoint: %s\n", err->message);
// // // //         return -1;
// // // //     }

// // // //     g_message("[Endpoint] MediaEndpoint1 exported (source + sink)");
// // // //     return 0;
// // // // }





// // //////////////////////////Harish working until select properties/////////////////////////////


// #include "bluez-media-endpoint.h"
// #include <gio/gio.h>
// #include <string.h>
// #include <stdint.h>

// #define EP_PATH_SOURCE "/local/endpoint/ep0"
// #define EP_PATH_SINK   "/local/endpoint/ep1"

// struct endpoint_ctx {
//     const char *path;
//     char *transport_path;
//     GVariant *codec_config;
//     GVariant *qos;
// };

// static struct endpoint_ctx ep_source = { .path = EP_PATH_SOURCE };
// static struct endpoint_ctx ep_sink   = { .path = EP_PATH_SINK };

// static const char endpoint_xml[] =
// "<node>"
// " <interface name='org.bluez.MediaEndpoint1'>"
// "  <method name='SelectProperties'>"
// "   <arg name='caps' type='a{sv}' direction='in'/>"
// "   <arg name='properties' type='a{sv}' direction='out'/>"
// "  </method>"
// "  <method name='SetConfiguration'>"
// "   <arg name='transport' type='o' direction='in'/>"
// "   <arg name='properties' type='a{sv}' direction='in'/>"
// "  </method>"
// "  <method name='ClearConfiguration'>"
// "   <arg name='transport' type='o' direction='in'/>"
// "  </method>"
// "  <method name='Release'/>"
// " </interface>"
// "</node>";

// /* ---------------------------------------------------- */
// /* SelectProperties – FIXED (16_2_1 preset)              */
// /* ---------------------------------------------------- */
// static void handle_select_properties(GDBusMethodInvocation *invocation,
//                                      GVariant *parameters,
//                                      struct endpoint_ctx *ctx)
// {
//     GVariant *caps;
//     g_variant_get(parameters, "(@a{sv})", &caps);

//     g_message("[Endpoint %s] SelectProperties", ctx->path);

//     /* LC3 preset: 16 kHz, 7.5 ms, mono, 40 octets (16_2_1) */
//     // static const uint8_t lc3_config[] = {
//     //     0x02, 0x01, 0x04,        /* Sampling Frequency = 16 kHz */
//     //     0x02, 0x02, 0x01,        /* Frame Duration = 7.5 ms */
//     //     0x02, 0x03, 0x01,        /* Channel Count = 1 */
//     //     0x03, 0x04, 0x28, 0x00   /* Frame Length = 40 bytes */
//     // };

//     // static const uint8_t lc3_config[] = {
//     //     0x02, 0x01, 0x03,      /* Sampling Frequency = 16 kHz */
//     //     0x02, 0x02, 0x02,      /* Frame Duration = 10 ms */
//     //     0x02, 0x03, 0x01,      /* Channel Count = 1 */
//     //     0x03, 0x04, 0x28, 0x00 /* Frame Length = 40 octets */
//     // };
//     static const uint8_t lc3_config[] = {
//     0x02, 0x01, 0x80,        /* Sampling Frequency = 48 kHz */
//     0x02, 0x02, 0x02,        /* Frame Duration = 10 ms */
//     0x02, 0x03, 0x01,        /* Channel Count = 1 */
//     0x03, 0x04, 0x78, 0x00   /* Frame Length = 120 octets */
// };

//     GVariantBuilder props;
//     g_variant_builder_init(&props, G_VARIANT_TYPE("a{sv}"));

//     g_variant_builder_add(&props, "{sv}",
//         "Codec", g_variant_new_byte(0x06)); /* LC3 */

//     // g_variant_builder_add(&props, "{sv}",
//     //     "CodecConfiguration",
//     //     g_variant_new_fixed_array(G_VARIANT_TYPE_BYTE,
//     //                               lc3_config,
//     //                               sizeof(lc3_config),
//     //                               1));  //1 change

//         g_variant_builder_add(&props, "{sv}", "CodecConfiguration",
//         g_variant_new_fixed_array(G_VARIANT_TYPE_BYTE,
//                                   lc3_config,
//                                   sizeof(lc3_config),
//                                   sizeof(uint8_t)));

//     g_variant_builder_add(&props, "{sv}",
//         "AudioLocations", g_variant_new_uint32(0x00000001));

//     /* QoS — BlueZ-compliant (NO Framing key!) */
//     GVariantBuilder qos;
//     g_variant_builder_init(&qos, G_VARIANT_TYPE("a{sv}"));

//     g_variant_builder_add(&qos, "{sv}",
//         "PHY", g_variant_new_byte(0x02)); /* 2M */

//     g_variant_builder_add(&qos, "{sv}",
//         "Interval", g_variant_new_uint32(10000)); /* 10 ms */

//     g_variant_builder_add(&qos, "{sv}",
//         "SDU", g_variant_new_uint16(120));
    
//     // guint16 sdu = 40;
//     // g_variant_builder_add(&qos, "{sv}",
//     // "SDU",
//     // g_variant_new_fixed_array(G_VARIANT_TYPE_UINT16,
//     //                           &sdu, 1, sizeof(guint16)));


//     g_variant_builder_add(&qos, "{sv}",
//         "Retransmissions", g_variant_new_byte(2));

//     g_variant_builder_add(&qos, "{sv}",
//         "Latency", g_variant_new_uint16(20));

//     g_variant_builder_add(&qos, "{sv}",
//         "TargetLatency", g_variant_new_byte(1)); /* balanced */

//     // g_variant_builder_add(&qos, "{sv}",
//     // "TargetLatency", g_variant_new_uint32(1));


//     g_variant_builder_add(&props, "{sv}",
//         "QoS", g_variant_builder_end(&qos));

//     g_dbus_method_invocation_return_value(
//         invocation,
//         g_variant_new("(@a{sv})", g_variant_builder_end(&props)));

//     g_variant_unref(caps);
// }




// // // // /* ---------------------------------------------------- */
// // // // /* SetConfiguration                                     */
// // // // /* ---------------------------------------------------- */
// static void handle_set_configuration(GDBusMethodInvocation *invocation,
//                                      GVariant *parameters,
//                                      struct endpoint_ctx *ctx)
// {
//     const char *transport;
//     GVariant *props;

//     g_variant_get(parameters, "(&o@a{sv})", &transport, &props);

//     g_message("[Endpoint %s] SetConfiguration", ctx->path);
//     g_message("  Transport: %s", transport);

//     g_free(ctx->transport_path);
//     ctx->transport_path = g_strdup(transport);

//     g_clear_pointer(&ctx->codec_config, g_variant_unref);
//     g_variant_lookup(props, "CodecConfiguration", "@ay", &ctx->codec_config);

//     g_clear_pointer(&ctx->qos, g_variant_unref);
//     g_variant_lookup(props, "QoS", "@a{sv}", &ctx->qos);

//     g_dbus_method_invocation_return_value(invocation, NULL);
//     g_variant_unref(props);
// }

// static void handle_clear_configuration(GDBusMethodInvocation *invocation,
//                                        struct endpoint_ctx *ctx)
// {
//     g_clear_pointer(&ctx->transport_path, g_free);
//     g_clear_pointer(&ctx->codec_config, g_variant_unref);
//     g_clear_pointer(&ctx->qos, g_variant_unref);
//     g_dbus_method_invocation_return_value(invocation, NULL);
// }

// static void handle_release(GDBusMethodInvocation *invocation,
//                            struct endpoint_ctx *ctx)
// {
//     g_dbus_method_invocation_return_value(invocation, NULL);
// }

// static void method_call_cb(GDBusConnection *conn,
//                            const char *sender,
//                            const char *path,
//                            const char *iface,
//                            const char *method,
//                            GVariant *params,
//                            GDBusMethodInvocation *inv,
//                            void *userdata)
// {
//     (void)conn; (void)sender; (void)iface; (void)userdata;
//     struct endpoint_ctx *ctx =
//         g_strcmp0(path, EP_PATH_SOURCE) == 0 ? &ep_source : &ep_sink;

//     if (!strcmp(method, "SelectProperties"))
//         handle_select_properties(inv, params, ctx);
//     else if (!strcmp(method, "SetConfiguration"))
//         handle_set_configuration(inv, params, ctx);
//     else if (!strcmp(method, "ClearConfiguration"))
//         handle_clear_configuration(inv, ctx);
//     else if (!strcmp(method, "Release"))
//         handle_release(inv, ctx);
// }



// // int media_endpoint_export(GDBusConnection *conn)
// // {
// //     GError *err = NULL;
// //     GDBusNodeInfo *node =
// //         g_dbus_node_info_new_for_xml(endpoint_xml, &err);

// //     g_dbus_connection_register_object(
// //         conn, EP_PATH_SOURCE, node->interfaces[0],
// //         &(GDBusInterfaceVTable){ .method_call = method_call_cb },
// //         NULL, NULL, NULL);

// //     g_dbus_connection_register_object(
// //         conn, EP_PATH_SINK, node->interfaces[0],
// //         &(GDBusInterfaceVTable){ .method_call = method_call_cb },
// //         NULL, NULL, NULL);

// //     return 0;
// // }


// int media_endpoint_export(GDBusConnection *conn)
// {
//     GError *err = NULL;
//     GDBusNodeInfo *node = g_dbus_node_info_new_for_xml(endpoint_xml, &err);

//     g_dbus_connection_register_object(
//         conn, EP_PATH_SOURCE, node->interfaces[0],
//         &(GDBusInterfaceVTable){ .method_call = method_call_cb },
//         NULL, NULL, &err);

//     g_dbus_connection_register_object(
//         conn, EP_PATH_SINK, node->interfaces[0],
//         &(GDBusInterfaceVTable){ .method_call = method_call_cb },
//         NULL, NULL, &err);

//     if (err) {
//         g_printerr("Failed to register endpoint: %s\n", err->message);
//         g_error_free(err);
//         return -1;
//     }
// g_dbus_node_info_unref(node);
//     return 0;
// }






// //////////////for configuration//////////////////////////********** */
// #include "bluez-media-endpoint.h"
// #include <gio/gio.h>
// #include <string.h>
// #include <stdint.h>

// #define EP_PATH_SOURCE "/local/endpoint/ep0"
// #define EP_PATH_SINK   "/local/endpoint/ep1"

// struct endpoint_ctx {
//     const char *path;
//     char *transport_path;
//     GVariant *codec_config;
//     GVariant *qos;
// };

// static struct endpoint_ctx ep_source = { .path = EP_PATH_SOURCE };
// static struct endpoint_ctx ep_sink   = { .path = EP_PATH_SINK };

// static const char endpoint_xml[] =
// "<node>"
// " <interface name='org.bluez.MediaEndpoint1'>"
// "  <method name='SelectProperties'>"
// "   <arg name='caps' type='a{sv}' direction='in'/>"
// "   <arg name='properties' type='a{sv}' direction='out'/>"
// "  </method>"
// "  <method name='SetConfiguration'>"
// "   <arg name='transport' type='o' direction='in'/>"
// "   <arg name='properties' type='a{sv}' direction='in'/>"
// "  </method>"
// "  <method name='ClearConfiguration'>"
// "   <arg name='transport' type='o' direction='in'/>"
// "  </method>"
// "  <method name='Release'/>"
// " </interface>"
// "</node>";

// /* ---------------------------------------------------- */
// /* SelectProperties – LC3 16 kHz, 10 ms, mono, 40 bytes */
// /* ---------------------------------------------------- */
// static void handle_select_properties(GDBusMethodInvocation *invocation,
//                                      GVariant *parameters,
//                                      struct endpoint_ctx *ctx)
// {
//     GVariant *caps;
//     g_variant_get(parameters, "(@a{sv})", &caps);

//     g_message("[Endpoint %s] SelectProperties", ctx->path);
// static const uint8_t lc3_codec_config_48k[] = {
// 	0x02, 0x01, 0x80, 0x00,   /* Sampling Frequency = 48 kHz */
// 	0x02, 0x02, 0x01,        /* Frame Duration = 10 ms */
// 	0x02, 0x03, 0x01,        /* Channel Count = 1 */
// 	0x05, 0x04,              /* Frame Length (set at runtime) */
// 		0x00, 0x00,           /* min */
// 		0x00, 0x00,           /* max */
// 	0x02, 0x05, 0x01         /* Max SDU = 1 */
// };


//     GVariantBuilder props;
//     g_variant_builder_init(&props, G_VARIANT_TYPE("a{sv}"));

//     g_variant_builder_add(&props, "{sv}",
//         "Codec", g_variant_new_byte(0x06)); /* LC3 */

//     g_variant_builder_add(&props, "{sv}",
//         "CodecConfiguration",
//         g_variant_new_fixed_array(G_VARIANT_TYPE_BYTE,
//                                   lc3_config,
//                                   sizeof(lc3_config),
//                                   1));

//     g_variant_builder_add(&props, "{sv}",
//         "AudioLocations", g_variant_new_uint32(0x00000001)); /* Front Left */

//     /* QoS dictionary */
//     GVariantBuilder qos;
//     g_variant_builder_init(&qos, G_VARIANT_TYPE("a{sv}"));

//     g_variant_builder_add(&qos, "{sv}",
//         "PHY", g_variant_new_byte(0x02));           /* LE 2M */
//     g_variant_builder_add(&qos, "{sv}",
//         "Interval", g_variant_new_uint32(10000));   /* 10 ms */
//     g_variant_builder_add(&qos, "{sv}",
//         "SDU", g_variant_new_uint16(40));           /* matches frame length */
//     g_variant_builder_add(&qos, "{sv}",
//         "Retransmissions", g_variant_new_byte(2));
//     g_variant_builder_add(&qos, "{sv}",
//         "Latency", g_variant_new_uint16(20));
//     g_variant_builder_add(&qos, "{sv}",
//         "TargetLatency", g_variant_new_byte(0x01)); /* balanced */

//     g_variant_builder_add(&props, "{sv}",
//         "QoS", g_variant_builder_end(&qos));

//     g_dbus_method_invocation_return_value(
//         invocation,
//         g_variant_new("(@a{sv})", g_variant_builder_end(&props)));

//     g_variant_unref(caps);
// }

// /* ---------------------------------------------------- */
// /* SetConfiguration                                     */
// /* ---------------------------------------------------- */
// static void handle_set_configuration(GDBusMethodInvocation *invocation,
//                                      GVariant *parameters,
//                                      struct endpoint_ctx *ctx)
// {
//     const char *transport;
//     GVariant *props;

//     g_variant_get(parameters, "(&o@a{sv})", &transport, &props);

//     g_message("[Endpoint %s] SetConfiguration", ctx->path);
//     g_message("  Transport: %s", transport);

//     g_free(ctx->transport_path);
//     ctx->transport_path = g_strdup(transport);

//     g_clear_pointer(&ctx->codec_config, g_variant_unref);
//     g_variant_lookup(props, "CodecConfiguration", "@ay", &ctx->codec_config);

//     g_clear_pointer(&ctx->qos, g_variant_unref);
//     g_variant_lookup(props, "QoS", "@a{sv}", &ctx->qos);

//     g_dbus_method_invocation_return_value(invocation, NULL);
//     g_variant_unref(props);
// }

// /* ---------------------------------------------------- */
// /* ClearConfiguration                                   */
// /* ---------------------------------------------------- */
// static void handle_clear_configuration(GDBusMethodInvocation *invocation,
//                                        struct endpoint_ctx *ctx)
// {
//     g_clear_pointer(&ctx->transport_path, g_free);
//     g_clear_pointer(&ctx->codec_config, g_variant_unref);
//     g_clear_pointer(&ctx->qos, g_variant_unref);
//     g_dbus_method_invocation_return_value(invocation, NULL);
// }

// /* ---------------------------------------------------- */
// /* Release                                              */
// /* ---------------------------------------------------- */
// static void handle_release(GDBusMethodInvocation *invocation,
//                            struct endpoint_ctx *ctx)
// {
//     (void)ctx;
//     g_dbus_method_invocation_return_value(invocation, NULL);
// }

// /* ---------------------------------------------------- */
// /* Dispatcher                                           */
// /* ---------------------------------------------------- */
// static void method_call_cb(GDBusConnection *conn,
//                            const char *sender,
//                            const char *path,
//                            const char *iface,
//                            const char *method,
//                            GVariant *params,
//                            GDBusMethodInvocation *inv,
//                            void *userdata)
// {
//     (void)conn;
//     (void)sender;
//     (void)iface;
//     (void)userdata;

//     struct endpoint_ctx *ctx =
//         g_strcmp0(path, EP_PATH_SOURCE) == 0 ? &ep_source : &ep_sink;

//     if (!strcmp(method, "SelectProperties"))
//         handle_select_properties(inv, params, ctx);
//     else if (!strcmp(method, "SetConfiguration"))
//         handle_set_configuration(inv, params, ctx);
//     else if (!strcmp(method, "ClearConfiguration"))
//         handle_clear_configuration(inv, ctx);
//     else if (!strcmp(method, "Release"))
//         handle_release(inv, ctx);
// }

// /* ---------------------------------------------------- */
// /* Export endpoints                                     */
// /* ---------------------------------------------------- */
// int media_endpoint_export(GDBusConnection *conn)
// {
//     GError *err = NULL;
//     GDBusNodeInfo *node =
//         g_dbus_node_info_new_for_xml(endpoint_xml, &err);

//     if (!node) {
//         g_printerr("Endpoint XML error: %s\n", err->message);
//         g_error_free(err);
//         return -1;
//     }

//     g_dbus_connection_register_object(
//         conn, EP_PATH_SOURCE, node->interfaces[0],
//         &(GDBusInterfaceVTable){ .method_call = method_call_cb },
//         NULL, NULL, NULL);

//     g_dbus_connection_register_object(
//         conn, EP_PATH_SINK, node->interfaces[0],
//         &(GDBusInterfaceVTable){ .method_call = method_call_cb },
//         NULL, NULL, NULL);

//     g_dbus_node_info_unref(node);
//     return 0;
// }






/////////////////////////////////chandu working last ///////////////////////////////
// // ////////////////////////////////auto-selection code////////////////////////////

// #include "bluez-media-endpoint.h"
// #include <gio/gio.h>
// #include <string.h>
// #include <stdint.h>

// #define EP_PATH_SOURCE "/local/endpoint/ep0"
// #define EP_PATH_SINK   "/local/endpoint/ep1"

// #define LC3_CODEC_ID 0x06

// struct endpoint_ctx {
//     const char *path;
// };

// static struct endpoint_ctx ep_source = { .path = EP_PATH_SOURCE };
// static struct endpoint_ctx ep_sink   = { .path = EP_PATH_SINK };

// static const char endpoint_xml[] =
// "<node>"
// " <interface name='org.bluez.MediaEndpoint1'>"
// "  <method name='SelectProperties'>"
// "   <arg name='caps' type='a{sv}' direction='in'/>"
// "   <arg name='properties' type='a{sv}' direction='out'/>"
// "  </method>"
// "  <method name='SetConfiguration'>"
// "   <arg name='transport' type='o' direction='in'/>"
// "   <arg name='properties' type='a{sv}' direction='in'/>"
// "  </method>"
// "  <method name='ClearConfiguration'>"
// "   <arg name='transport' type='o' direction='in'/>"
// "  </method>"
// "  <method name='Release'/>"
// " </interface>"
// "</node>";

// /* ---------------------------------------------------- */
// /* LC3 auto-selection helper                            */
// /* ---------------------------------------------------- */
// static void build_lc3_codec_config(uint8_t *cfg, size_t *len,
//                                    uint16_t frame_len)
// {
//     uint8_t *p = cfg;

//     /* Sampling Frequency = 48 kHz */
//     *p++ = 0x02; *p++ = 0x01; *p++ = 0x80; *p++ = 0x00;

//     /* Frame Duration = 10 ms */
//     *p++ = 0x02; *p++ = 0x02; *p++ = 0x02;

//     /* Channel Count = 1 */
//     *p++ = 0x02; *p++ = 0x03; *p++ = 0x01;

//     /* Frame Length (exact value) */
//     *p++ = 0x05; *p++ = 0x04;
//     *p++ = frame_len & 0xff;
//     *p++ = frame_len >> 8;
//     *p++ = frame_len & 0xff;
//     *p++ = frame_len >> 8;

//     /* Max SDU = 1 */
//     *p++ = 0x02; *p++ = 0x05; *p++ = 0x01;

//     *len = p - cfg;
// }

// /* ---------------------------------------------------- */
// /* SelectProperties – AUTO SELECTION                    */
// /* ---------------------------------------------------- */
// static void handle_select_properties(GDBusMethodInvocation *invocation,
//                                      GVariant *parameters,
//                                      struct endpoint_ctx *ctx)
// {
//     GVariant *caps;
//     g_variant_get(parameters, "(@a{sv})", &caps);

//     uint16_t min_fl = 0, max_fl = 0;

//     /* Parse Frame Length from PAC */
//     GVariant *cc = g_variant_lookup_value(caps, "CodecCapabilities",
//                                           G_VARIANT_TYPE("ay"));
//     if (cc) {
//         const uint8_t *d;
//         size_t len;
//         d = g_variant_get_fixed_array(cc, &len, 1);

//         for (size_t i = 0; i + 1 < len;) {
//             uint8_t l = d[i];
//             uint8_t t = d[i + 1];

//             if (t == 0x04 && l == 0x05) { /* Frame Length */
//                 min_fl = d[i + 2] | (d[i + 3] << 8);
//                 max_fl = d[i + 4] | (d[i + 5] << 8);
//                 break;
//             }
//             i += l + 1;
//         }
//         g_variant_unref(cc);
//     }

//     if (!max_fl)
//         max_fl = 155; /* safe fallback */

//     uint8_t codec_cfg[32];
//     size_t codec_len;

//     build_lc3_codec_config(codec_cfg, &codec_len, max_fl);

//     GVariantBuilder props;
//     g_variant_builder_init(&props, G_VARIANT_TYPE("a{sv}"));

//     g_variant_builder_add(&props, "{sv}",
//         "Codec", g_variant_new_byte(LC3_CODEC_ID));

//     g_variant_builder_add(&props, "{sv}",
//         "CodecConfiguration",
//         g_variant_new_fixed_array(G_VARIANT_TYPE_BYTE,
//                                   codec_cfg, codec_len, 1));

//     g_variant_builder_add(&props, "{sv}",
//         "AudioLocations", g_variant_new_uint32(0x00000001));

//     /* QoS */
//     GVariantBuilder qos;
//     g_variant_builder_init(&qos, G_VARIANT_TYPE("a{sv}"));

//     g_variant_builder_add(&qos, "{sv}",
//         "Interval", g_variant_new_uint32(10000));
//     // g_variant_builder_add(&qos, "{sv}",
//     //     "SDU", g_variant_new_uint16(max_fl));
// uint16_t sdu = max_fl + 4;

// g_variant_builder_add(&qos, "{sv}",
//     "SDU", g_variant_new_uint16(sdu));



//     g_variant_builder_add(&qos, "{sv}",
//         "PHY", g_variant_new_byte(0x02));
//     g_variant_builder_add(&qos, "{sv}",
//         "Retransmissions", g_variant_new_byte(2));
//     g_variant_builder_add(&qos, "{sv}",
//         "Latency", g_variant_new_uint16(20));

//     g_variant_builder_add(&props, "{sv}",
//         "QoS", g_variant_builder_end(&qos));

//     g_dbus_method_invocation_return_value(
//         invocation,
//         g_variant_new("(@a{sv})",
//             g_variant_builder_end(&props)));

//     g_variant_unref(caps);
// }

// /* ---------------------------------------------------- */
// /* Boilerplate handlers                                 */
// /* ---------------------------------------------------- */
// static void handle_set_configuration(GDBusMethodInvocation *invocation,
//                                      GVariant *parameters,
//                                      struct endpoint_ctx *ctx)
// {
//     g_dbus_method_invocation_return_value(invocation, NULL);
// }

// static void handle_clear_configuration(GDBusMethodInvocation *invocation,
//                                        struct endpoint_ctx *ctx)
// {
//     g_dbus_method_invocation_return_value(invocation, NULL);
// }

// static void handle_release(GDBusMethodInvocation *invocation,
//                            struct endpoint_ctx *ctx)
// {
//     g_dbus_method_invocation_return_value(invocation, NULL);
// }

// static void method_call_cb(GDBusConnection *conn,
//                            const char *sender,
//                            const char *path,
//                            const char *iface,
//                            const char *method,
//                            GVariant *params,
//                            GDBusMethodInvocation *inv,
//                            void *userdata)
// {
//     struct endpoint_ctx *ctx =
//         strcmp(path, EP_PATH_SOURCE) == 0 ? &ep_source : &ep_sink;

//     if (!strcmp(method, "SelectProperties"))
//         handle_select_properties(inv, params, ctx);
//     else if (!strcmp(method, "SetConfiguration"))
//         handle_set_configuration(inv, params, ctx);
//     else if (!strcmp(method, "ClearConfiguration"))
//         handle_clear_configuration(inv, ctx);
//     else if (!strcmp(method, "Release"))
//         handle_release(inv, ctx);
// }

// int media_endpoint_export(GDBusConnection *conn)
// {
//     GDBusNodeInfo *node =
//         g_dbus_node_info_new_for_xml(endpoint_xml, NULL);

//     g_dbus_connection_register_object(
//         conn, EP_PATH_SOURCE, node->interfaces[0],
//         &(GDBusInterfaceVTable){ .method_call = method_call_cb },
//         NULL, NULL, NULL);

//     g_dbus_connection_register_object(
//         conn, EP_PATH_SINK, node->interfaces[0],
//         &(GDBusInterfaceVTable){ .method_call = method_call_cb },
//         NULL, NULL, NULL);

//     g_dbus_node_info_unref(node);
//     return 0;
// }


/////////////////////////set-configuratuion///////////////////////////////
// #include "bluez-media-endpoint.h"
// #include <gio/gio.h>
// #include <stdint.h>
// #include <string.h>
// #include <stdio.h>

// #define EP_PATH_SOURCE "/local/endpoint/ep0"
// #define EP_PATH_SINK   "/local/endpoint/ep1"
// #define LC3_CODEC_ID   0x06

// /* LC3 config parsed */
// struct lc3_cfg {
//     uint32_t freq;
//     uint32_t frame_dur;
//     uint16_t frame_len;
//     uint8_t  channels;
// };

// /* Endpoint context */
// struct endpoint_ctx {
//     const char *path;
//     char *transport_path;
//     struct lc3_cfg lc3;
//     gboolean configured;
// };

// static struct endpoint_ctx ep_source = { .path = EP_PATH_SOURCE };
// static struct endpoint_ctx ep_sink   = { .path = EP_PATH_SINK };

// /* MediaEndpoint XML */
// static const char endpoint_xml[] =
// "<node>"
// " <interface name='org.bluez.MediaEndpoint1'>"
// "  <method name='SelectProperties'>"
// "   <arg name='caps' type='a{sv}' direction='in'/>"
// "   <arg name='properties' type='a{sv}' direction='out'/>"
// "  </method>"
// "  <method name='SetConfiguration'>"
// "   <arg name='transport' type='o' direction='in'/>"
// "   <arg name='properties' type='a{sv}' direction='in'/>"
// "  </method>"
// "  <method name='ClearConfiguration'>"
// "   <arg name='transport' type='o' direction='in'/>"
// "  </method>"
// "  <method name='Release'/>"
// " </interface>"
// "</node>";

// /* ---------------------------------------------------- */
// /* SelectProperties — hint only                         */
// /* ---------------------------------------------------- */
// static void handle_select_properties(GDBusMethodInvocation *invocation,
//                                      GVariant *parameters,
//                                      struct endpoint_ctx *ctx)
// {
//     (void)parameters;
//     (void)ctx;
//     static const uint8_t lc3_cfg[] = {
//         0x02, 0x01, 0x80,        /* 48 kHz */
//         0x02, 0x02, 0x02,        /* 10 ms */
//         0x02, 0x03, 0x01,        /* mono */
//         0x03, 0x04, 0x50, 0x00   /* 80 octets */
//     };

//     GVariantBuilder props;
//     g_variant_builder_init(&props, G_VARIANT_TYPE("a{sv}"));

//     g_variant_builder_add(&props, "{sv}", "Codec",
//                           g_variant_new_byte(LC3_CODEC_ID));

//     g_variant_builder_add(&props, "{sv}", "CodecConfiguration",
//         g_variant_new_from_data(G_VARIANT_TYPE("ay"),
//                                 lc3_cfg, sizeof(lc3_cfg),
//                                 TRUE, NULL, NULL));

//     g_dbus_method_invocation_return_value(
//         invocation,
//         g_variant_new("(a{sv})", &props));
// }

// /* ---------------------------------------------------- */
// /* Parse LC3 TLVs                                       */
// /* ---------------------------------------------------- */
// static gboolean parse_lc3(const uint8_t *p, size_t len,
//                           struct endpoint_ctx *ctx)
// {
//     size_t i = 0;

//     while (i + 1 < len) {
//         uint8_t l = p[i];
//         uint8_t t = p[i + 1];

//         if (i + 1 + l > len)
//             return FALSE;

//         switch (t) {
//         case 0x01: /* Frequency */
//             ctx->lc3.freq = p[i + 2];
//             break;
//         case 0x02: /* Frame Duration */
//             ctx->lc3.frame_dur = p[i + 2];
//             break;
//         case 0x03: /* Channels */
//             ctx->lc3.channels = p[i + 2];
//             break;
//         case 0x04: /* Frame Length */
//             ctx->lc3.frame_len = p[i + 2] | (p[i + 3] << 8);
//             break;
//         }
//         i += 1 + l;
//     }
//     return TRUE;
// }

// /* ---------------------------------------------------- */
// /* 🔥 SetConfiguration — FINAL LOCK POINT                */
// /* ---------------------------------------------------- */
// static void handle_set_configuration(GDBusMethodInvocation *invocation,
//                                      GVariant *parameters,
//                                      struct endpoint_ctx *ctx)
// {
//     const char *transport;
//     GVariant *props;
//     GVariant *cfg;
//     gsize len;
//     const uint8_t *data;

//     g_variant_get(parameters, "(&o@a{sv})", &transport, &props);
//     g_variant_lookup(props, "CodecConfiguration", "@ay", &cfg);

//     data = g_variant_get_fixed_array(cfg, &len, sizeof(uint8_t));

//     memset(&ctx->lc3, 0, sizeof(ctx->lc3));

//     if (!parse_lc3(data, len, ctx) || ctx->lc3.frame_len == 0) {
//         g_dbus_method_invocation_return_error(
//             invocation, G_IO_ERROR, G_IO_ERROR_FAILED,
//             "Invalid LC3 configuration");
//         return;
//     }

//     ctx->configured = TRUE;
//     ctx->transport_path = g_strdup(transport);

//     g_message("LC3 CONFIG LOCKED:");
//     g_message("  freq=%u frame_dur=%u frame_len=%u channels=%u",
//               ctx->lc3.freq,
//               ctx->lc3.frame_dur,
//               ctx->lc3.frame_len,
//               ctx->lc3.channels);

//     g_dbus_method_invocation_return_value(invocation, NULL);

//     g_variant_unref(cfg);
//     g_variant_unref(props);
// }

// /* ---------------------------------------------------- */
// static void handle_clear_configuration(GDBusMethodInvocation *inv,
//                                        struct endpoint_ctx *ctx)
// {
//     (void)ctx;
//     ctx->configured = FALSE;
//     g_clear_pointer(&ctx->transport_path, g_free);
//     g_dbus_method_invocation_return_value(inv, NULL);
// }

// /* ---------------------------------------------------- */
// static void handle_release(GDBusMethodInvocation *inv,
//                            struct endpoint_ctx *ctx)
// {
//     (void)ctx;
//     g_dbus_method_invocation_return_value(inv, NULL);
// }

// /* ---------------------------------------------------- */
// static void method_call_cb(GDBusConnection *conn,
//                            const char *sender,
//                            const char *path,
//                            const char *iface,
//                            const char *method,
//                            GVariant *params,
//                            GDBusMethodInvocation *inv,
//                            void *userdata)
// {
//     (void)conn; (void)sender; (void)iface; (void)userdata;

//     struct endpoint_ctx *ctx =
//         strcmp(path, EP_PATH_SOURCE) == 0 ? &ep_source : &ep_sink;

//     if (!strcmp(method, "SelectProperties"))
//         handle_select_properties(inv, params, ctx);
//     else if (!strcmp(method, "SetConfiguration"))
//         handle_set_configuration(inv, params, ctx);
//     else if (!strcmp(method, "ClearConfiguration"))
//         handle_clear_configuration(inv, ctx);
//     else if (!strcmp(method, "Release"))
//         handle_release(inv, ctx);
// }

// /* ---------------------------------------------------- */
// int media_endpoint_export(GDBusConnection *conn)
// {
//     GError *err = NULL;
//     GDBusNodeInfo *node =
//         g_dbus_node_info_new_for_xml(endpoint_xml, &err);

//     static const GDBusInterfaceVTable vtable = {
//         .method_call = method_call_cb,
//     };

//     g_dbus_connection_register_object(
//         conn, EP_PATH_SOURCE, node->interfaces[0],
//         &vtable, NULL, NULL, NULL);

//     g_dbus_connection_register_object(
//         conn, EP_PATH_SINK, node->interfaces[0],
//         &vtable, NULL, NULL, NULL);

//     g_message("Media endpoints registered");
//     g_dbus_node_info_unref(node);
//     return 0;
// }

/////////working 3:10pm lunch///////////////////////////////
// #include "bluez-media-endpoint.h"
// #include <gio/gio.h>
// #include <stdint.h>
// #include <string.h>
// #include <stdio.h>

// #define EP_PATH_SOURCE "/local/endpoint/ep0"
// #define EP_PATH_SINK   "/local/endpoint/ep1"
// #define LC3_CODEC_ID   0x06

// /* ---------------- LC3 + QoS ---------------- */

// struct lc3_cfg {
//     uint32_t freq;
//     uint32_t frame_dur;
//     uint16_t frame_len;
//     uint8_t  channels;
// };

// struct qos_cfg {
//     uint32_t interval_us;
//     uint8_t  framing;
//     uint8_t  phy;
//     uint16_t sdu;
//     uint8_t  rtn;
//     uint16_t latency;
// };

// struct endpoint_ctx {
//     const char *path;
//     char *transport_path;
//     struct lc3_cfg lc3;
//     struct qos_cfg qos;
//     gboolean configured;
// };

// static struct endpoint_ctx ep_source = { .path = EP_PATH_SOURCE };
// static struct endpoint_ctx ep_sink   = { .path = EP_PATH_SINK };

// /* ---------------- XML ---------------- */

// static const char endpoint_xml[] =
// "<node>"
// " <interface name='org.bluez.MediaEndpoint1'>"
// "  <method name='SelectProperties'>"
// "   <arg name='caps' type='a{sv}' direction='in'/>"
// "   <arg name='properties' type='a{sv}' direction='out'/>"
// "  </method>"
// "  <method name='SetConfiguration'>"
// "   <arg name='transport' type='o' direction='in'/>"
// "   <arg name='properties' type='a{sv}' direction='in'/>"
// "  </method>"
// "  <method name='ClearConfiguration'>"
// "   <arg name='transport' type='o' direction='in'/>"
// "  </method>"
// "  <method name='Release'/>"
// " </interface>"
// "</node>";

// /* ---------------- SelectProperties (hint only) ---------------- */

// static void handle_select_properties(GDBusMethodInvocation *inv,
//                                      GVariant *params,
//                                      struct endpoint_ctx *ctx)
// {
//     (void)params; (void)ctx;

//     static const uint8_t fixed_lc3_cfg[] = {
//         0x02, 0x01, 0x80,        /* 48 kHz */
//         0x02, 0x02, 0x02,        /* 10 ms */
//         0x02, 0x03, 0x01,        /* mono */
//         0x03, 0x04, 0x50, 0x00   /* 80 octets */
//     };

//     GVariantBuilder b;
//     g_variant_builder_init(&b, G_VARIANT_TYPE("a{sv}"));

//     g_variant_builder_add(&b, "{sv}", "Codec",
//         g_variant_new_byte(LC3_CODEC_ID));

//     g_variant_builder_add(&b, "{sv}", "CodecConfiguration",
//         g_variant_new_fixed_array(G_VARIANT_TYPE_BYTE,
//                                   fixed_lc3_cfg,
//                                   sizeof(fixed_lc3_cfg),
//                                   sizeof(uint8_t)));

//     g_dbus_method_invocation_return_value(inv,
//         g_variant_new("(a{sv})", &b));
// }

// /* ---------------- LC3 TLV parser ---------------- */

// static gboolean parse_lc3(const uint8_t *p, size_t len,
//                           struct endpoint_ctx *ctx)
// {
//     size_t i = 0;

//     while (i + 2 <= len) {
//         uint8_t l = p[i];
//         uint8_t t = p[i + 1];

//         if (i + 2 + (l - 1) > len)
//             return FALSE;

//         const uint8_t *v = &p[i + 2];

//         switch (t) {
//         case 0x01: ctx->lc3.freq = v[0]; break;
//         case 0x02: ctx->lc3.frame_dur = v[0]; break;
//         case 0x03: ctx->lc3.channels = v[0]; break;
//         case 0x04:
//             if (l != 3) return FALSE;
//             ctx->lc3.frame_len = v[0] | (v[1] << 8);
//             break;
//         }

//         i += 1 + l;
//     }

//     return ctx->lc3.frame_len != 0;
// }

// /* ---------------- QoS parser ---------------- */

// // static void parse_qos(GVariant *props, struct endpoint_ctx *ctx)
// // {
// //     GVariantIter *iter;
// //     const char *key;
// //     GVariant *val;

// //     /* Safe defaults */
// //     ctx->qos.interval_us = 10000;
// //     ctx->qos.framing = 0;
// //     ctx->qos.phy = 2;
// //     ctx->qos.sdu = ctx->lc3.frame_len;
// //     ctx->qos.rtn = 2;
// //     ctx->qos.latency = 20;

// //     if (!g_variant_lookup(props, "QoS", "a{sv}", &iter))
// //         return;

// //     while (g_variant_iter_loop(iter, "{&sv}", &key, &val)) {
// //         if (!strcmp(key, "Interval"))
// //             ctx->qos.interval_us = g_variant_get_uint32(val);
// //         else if (!strcmp(key, "Framing"))
// //             ctx->qos.framing = g_variant_get_byte(val);
// //         else if (!strcmp(key, "PHY"))
// //             ctx->qos.phy = g_variant_get_byte(val);
// //         else if (!strcmp(key, "SDU"))
// //             ctx->qos.sdu = g_variant_get_uint16(val);
// //         else if (!strcmp(key, "Retransmission"))
// //             ctx->qos.rtn = g_variant_get_byte(val);
// //         else if (!strcmp(key, "Latency"))
// //             ctx->qos.latency = g_variant_get_uint16(val);
// //     }

// //     if (ctx->qos.latency == 0)
// //         ctx->qos.latency = 20;
// // }

// static gboolean parse_qos_tlv(const uint8_t *p, size_t len,
//                               struct endpoint_ctx *ctx)
// {
//     size_t i = 0;

//     /* sane defaults (but will be overwritten) */
//     memset(&ctx->qos, 0, sizeof(ctx->qos));

//     while (i + 2 <= len) {
//         uint8_t l = p[i];
//         uint8_t t = p[i + 1];

//         if (i + 2 + (l - 1) > len)
//             return FALSE;

//         const uint8_t *v = &p[i + 2];

//         switch (t) {
//         case 0x01: /* Framing */
//             ctx->qos.framing = v[0];
//             break;
//         case 0x02: /* PHY */
//             ctx->qos.phy = v[0];
//             break;
//         case 0x03: /* Max SDU */
//             ctx->qos.sdu = v[0] | (v[1] << 8);
//             break;
//         case 0x04: /* RTN */
//             ctx->qos.rtn = v[0];
//             break;
//         case 0x05: /* Latency */
//             ctx->qos.latency = v[0] | (v[1] << 8);
//             break;
//         case 0x06: /* Interval */
//             ctx->qos.interval_us =
//                 v[0] | (v[1] << 8) | (v[2] << 16);
//             break;
//         default:
//             break;
//         }

//         i += 1 + l;
//     }

//     /* critical validation */
//     if (ctx->qos.sdu < ctx->lc3.frame_len)
//         return FALSE;

//     return TRUE;
// }


// static void normalize_qos_for_lc3(struct endpoint_ctx *ctx)
// {
//     /* Enforce controller-compatible QoS */

//     /* LC3 → ISO interval mapping */
//     if (ctx->lc3.frame_dur == 0x02) {        /* 10 ms */
//         ctx->qos.interval_us = 8000;
//     } else if (ctx->lc3.frame_dur == 0x01) { /* 7.5 ms */
//         ctx->qos.interval_us = 7500;
//     }

//     /* nRF5340 constraints */
//     ctx->qos.framing = 0;     /* unframed */
//     ctx->qos.phy = 2;         /* 2M PHY */
//     ctx->qos.rtn = ctx->qos.rtn > 2 ? 2 : ctx->qos.rtn;

//     /* SDU must be >= frame length */
//     if (ctx->qos.sdu < ctx->lc3.frame_len)
       		
//         ctx->qos.sdu = ctx->lc3.frame_len;

//     /* Latency clamp */
//     if (ctx->qos.latency == 0 || ctx->qos.latency > 40)
//         ctx->qos.latency = 20;
// }


// /* ---------------- SetConfiguration (LOCK POINT) ---------------- */

// static void handle_set_configuration(GDBusMethodInvocation *inv,
//                                      GVariant *params,
//                                      struct endpoint_ctx *ctx)
// {
//     const char *transport;
//     GVariant *props = NULL;
//     GVariant *cfg = NULL;
//     GVariant *qos = NULL;
//     const uint8_t *data;
//     gsize len;

//     g_variant_get(params, "(&o@a{sv})", &transport, &props);

//     /* =========================================================
//      * 1. Parse CodecConfiguration (LC3)
//      * ========================================================= */
//     if (!g_variant_lookup(props, "CodecConfiguration", "@ay", &cfg)) {
//         g_dbus_method_invocation_return_error(
//             inv, G_IO_ERROR, G_IO_ERROR_FAILED,
//             "Missing CodecConfiguration");
//         return;
//     }

//     data = g_variant_get_fixed_array(cfg, &len, 1);
//     memset(&ctx->lc3, 0, sizeof(ctx->lc3));

//     if (!parse_lc3(data, len, ctx)) {
//         g_dbus_method_invocation_return_error(
//             inv, G_IO_ERROR, G_IO_ERROR_FAILED,
//             "Invalid LC3 configuration");
//         return;
//     }

//     /* ---- HARD LOCK (PipeWire behavior) ---- */
//     if (ctx->lc3.freq != 0x80 ||        /* 48 kHz */
//         ctx->lc3.frame_dur != 0x02 ||   /* 10 ms */
//         ctx->lc3.channels != 1 ||
//         ctx->lc3.frame_len != 80) {

//         g_dbus_method_invocation_return_error(
//             inv, G_IO_ERROR, G_IO_ERROR_FAILED,
//             "Unsupported LC3 parameters");
//         return;
//     }

//     /* =========================================================
//      * 2. Parse QoS (REAL QoS, not codec TLVs)
//      * ========================================================= */
//     if (!g_variant_lookup(props, "QoS", "@ay", &qos)) {
//         g_dbus_method_invocation_return_error(
//             inv, G_IO_ERROR, G_IO_ERROR_FAILED,
//             "Missing QoS");
//         return;
//     }

//     data = g_variant_get_fixed_array(qos, &len, 1);
//     memset(&ctx->qos, 0, sizeof(ctx->qos));

//     if (!parse_qos_tlv(data, len, ctx)) {
//         g_dbus_method_invocation_return_error(
//             inv, G_IO_ERROR, G_IO_ERROR_FAILED,
//             "Invalid QoS");
//         return;
//     }

//     /* =========================================================
//      * 3. Normalize QoS (THIS IS THE FIX)
//      * ========================================================= */
//     /* LC3 10 ms → ISO 10 ms */
//     ctx->qos.interval_us = 10000;

//     /* Controller constraints */
//     ctx->qos.framing = 0;       /* unframed */
//     ctx->qos.phy = 2;           /* 2M PHY */
//     ctx->qos.rtn = 2;           /* safe */
//     ctx->qos.latency = 20;      /* ms */

//     /* SDU MUST equal frame length */
//     ctx->qos.sdu = ctx->lc3.frame_len;

//     /* =========================================================
//      * 4. FINAL SAFETY CHECK (prevents controller reject)
//      * ========================================================= */
//     if (ctx->qos.sdu < ctx->lc3.frame_len ||
//         ctx->qos.interval_us != 10000 ||
//         ctx->qos.phy != 2) {

//         g_dbus_method_invocation_return_error(
//             inv, G_IO_ERROR, G_IO_ERROR_FAILED,
//             "QoS/LC3 mismatch");
//         return;
//     }

//     /* =========================================================
//      * 5. Commit configuration
//      * ========================================================= */
//     g_clear_pointer(&ctx->transport_path, g_free);
//     ctx->transport_path = g_strdup(transport);
//     ctx->configured = TRUE;

//     g_message("LC3 LOCKED: 48kHz 10ms mono frame=80");
//     g_message("QoS LOCKED: interval=%u us sdu=%u phy=%u rtn=%u latency=%u",
//               ctx->qos.interval_us,
//               ctx->qos.sdu,
//               ctx->qos.phy,
//               ctx->qos.rtn,
//               ctx->qos.latency);

//     g_dbus_method_invocation_return_value(inv, NULL);
// }



// /* ---------------- Clear / Release ---------------- */

// static void handle_clear_configuration(GDBusMethodInvocation *inv,
//                                        struct endpoint_ctx *ctx)
// {
//     ctx->configured = FALSE;
//     g_clear_pointer(&ctx->transport_path, g_free);
//     g_dbus_method_invocation_return_value(inv, NULL);
// }

// static void handle_release(GDBusMethodInvocation *inv,
//                            struct endpoint_ctx *ctx)
// {
//     (void)ctx;
//     g_dbus_method_invocation_return_value(inv, NULL);
// }

// /* ---------------- Dispatcher ---------------- */

// static void method_call_cb(GDBusConnection *c, const char *s,
//                            const char *path, const char *i,
//                            const char *m, GVariant *p,
//                            GDBusMethodInvocation *inv, void *u)
// {
//     (void)c; (void)s; (void)i; (void)u;

//     struct endpoint_ctx *ctx =
//         strcmp(path, EP_PATH_SOURCE) == 0 ? &ep_source : &ep_sink;

//     if (!strcmp(m, "SelectProperties"))
//         handle_select_properties(inv, p, ctx);
//     else if (!strcmp(m, "SetConfiguration"))
//         handle_set_configuration(inv, p, ctx);
//     else if (!strcmp(m, "ClearConfiguration"))
//         handle_clear_configuration(inv, ctx);
//     else if (!strcmp(m, "Release"))
//         handle_release(inv, ctx);
// }

// /* ---------------- Export ---------------- */

// int media_endpoint_export(GDBusConnection *conn)
// {
//     GError *err = NULL;
//     GDBusNodeInfo *node =
//         g_dbus_node_info_new_for_xml(endpoint_xml, &err);

//     static const GDBusInterfaceVTable vt = {
//         .method_call = method_call_cb,
//     };

//     g_dbus_connection_register_object(
//         conn, EP_PATH_SOURCE, node->interfaces[0],
//         &vt, NULL, NULL, NULL);

//     g_dbus_connection_register_object(
//         conn, EP_PATH_SINK, node->interfaces[0],
//         &vt, NULL, NULL, NULL);

//     g_message("Media endpoints registered");
//     g_dbus_node_info_unref(node);
//     return 0;
// }



// #include "bluez-media-endpoint.h"
// #include <gio/gio.h>
// #include <stdint.h>
// #include <string.h>
// #include <stdio.h>

// #define EP_PATH_SOURCE "/local/endpoint/ep0"
// #define EP_PATH_SINK   "/local/endpoint/ep1"
// #define LC3_CODEC_ID   0x06

// /* ---------------- LC3 ---------------- */

// struct lc3_cfg {
//     uint8_t  freq;
//     uint8_t  frame_dur;
//     uint16_t frame_len;
//     uint8_t  channels;
// };

// struct endpoint_ctx {
//     const char *path;
//     char *transport_path;
//     struct lc3_cfg lc3;
//     gboolean configured;
// };

// static struct endpoint_ctx ep_source = { .path = EP_PATH_SOURCE };
// static struct endpoint_ctx ep_sink   = { .path = EP_PATH_SINK };

// /* ---------------- XML ---------------- */

// static const char endpoint_xml[] =
// "<node>"
// " <interface name='org.bluez.MediaEndpoint1'>"
// "  <method name='SelectProperties'>"
// "   <arg name='caps' type='a{sv}' direction='in'/>"
// "   <arg name='properties' type='a{sv}' direction='out'/>"
// "  </method>"
// "  <method name='SetConfiguration'>"
// "   <arg name='transport' type='o' direction='in'/>"
// "   <arg name='properties' type='a{sv}' direction='in'/>"
// "  </method>"
// "  <method name='Acquire'>"
// "   <arg name='fd' type='h' direction='out'/>"
// "   <arg name='mtu' type='q' direction='out'/>"
// "   <arg name='interval' type='q' direction='out'/>"
// "  </method>"
// "  <method name='ClearConfiguration'>"
// "   <arg name='transport' type='o' direction='in'/>"
// "  </method>"
// "  <method name='Release'/>"
// " </interface>"
// "</node>";

// /* ---------------- SelectProperties ---------------- */

// static void handle_select_properties(GDBusMethodInvocation *inv,
//                                      GVariant *params,
//                                      struct endpoint_ctx *ctx)
// {
//     (void)params;
//     (void)ctx;

//     static const uint8_t lc3_cfg[] = {
//         0x02, 0x01, 0x80,        /* 48 kHz */
//         0x02, 0x02, 0x02,        /* 10 ms */
//         0x02, 0x03, 0x01,        /* mono */
//         0x03, 0x04, 0x50, 0x00   /* 80 bytes */
//     };

//     GVariantBuilder props;
//     g_variant_builder_init(&props, G_VARIANT_TYPE("a{sv}"));

//     g_variant_builder_add(&props, "{sv}",
//         "Codec", g_variant_new_byte(LC3_CODEC_ID));

//     g_variant_builder_add(&props, "{sv}",
//         "CodecConfiguration",
//         g_variant_new_fixed_array(G_VARIANT_TYPE_BYTE,
//                                   lc3_cfg,
//                                   sizeof(lc3_cfg),
//                                   1));

//     /* QoS */
//     GVariantBuilder qos, ucast;
//     g_variant_builder_init(&qos, G_VARIANT_TYPE("a{sv}"));
//     g_variant_builder_init(&ucast, G_VARIANT_TYPE("a{sv}"));

//     g_variant_builder_add(&ucast, "{sv}",
//         "TargetLatency", g_variant_new_byte(0x01));
//     g_variant_builder_add(&ucast, "{sv}",
//         "PHY", g_variant_new_byte(0x02));
//     g_variant_builder_add(&ucast, "{sv}",
//         "Interval", g_variant_new_uint32(10000));
//     g_variant_builder_add(&ucast, "{sv}",
//         "SDU", g_variant_new_uint16(80));
//     g_variant_builder_add(&ucast, "{sv}",
//         "Retransmissions", g_variant_new_byte(2));

//     g_variant_builder_add(&qos, "{sv}",
//         "Unicast", g_variant_builder_end(&ucast));

//     g_variant_builder_add(&props, "{sv}",
//         "QoS", g_variant_builder_end(&qos));

//     /* Metadata empty */
//     GVariantBuilder meta;
//     g_variant_builder_init(&meta, G_VARIANT_TYPE("a{sv}"));
//     g_variant_builder_add(&props, "{sv}",
//         "Metadata", g_variant_builder_end(&meta));

//     g_dbus_method_invocation_return_value(
//         inv, g_variant_new("(a{sv})", &props));
// }

// /* ---------------- LC3 TLV parser ---------------- */

// static gboolean parse_lc3(const uint8_t *p, size_t len,
//                           struct endpoint_ctx *ctx)
// {
//     size_t i = 0;
//     memset(&ctx->lc3, 0, sizeof(ctx->lc3));

//     while (i + 2 <= len) {
//         uint8_t l = p[i];
//         uint8_t t = p[i + 1];
//         const uint8_t *v = &p[i + 2];

//         if (i + 1 + l > len)
//             return FALSE;

//         switch (t) {
//         case 0x01: ctx->lc3.freq = v[0]; break;
//         case 0x02: ctx->lc3.frame_dur = v[0]; break;
//         case 0x03: ctx->lc3.channels = v[0]; break;
//         case 0x04:
//             ctx->lc3.frame_len = v[0] | (v[1] << 8);
//             break;
//         }

//         i += 1 + l;
//     }

//     return (ctx->lc3.freq == 0x80 &&
//             ctx->lc3.frame_dur == 0x02 &&
//             ctx->lc3.channels == 1 &&
//             ctx->lc3.frame_len == 80);
// }

// /* ---------------- SetConfiguration ---------------- */

// static void handle_set_configuration(GDBusMethodInvocation *inv,
//                                      GVariant *params,
//                                      struct endpoint_ctx *ctx)
// {
//     const char *transport;
//     GVariant *props;
//     GVariant *cfg;
//     const uint8_t *data;
//     gsize len;

//     g_variant_get(params, "(&o@a{sv})", &transport, &props);

//     if (!g_variant_lookup(props, "CodecConfiguration", "@ay", &cfg)) {
//         g_dbus_method_invocation_return_error(
//             inv, G_IO_ERROR, G_IO_ERROR_FAILED,
//             "Missing CodecConfiguration");
//         return;
//     }

//     data = g_variant_get_fixed_array(cfg, &len, 1);

//     if (!parse_lc3(data, len, ctx)) {
//         g_dbus_method_invocation_return_error(
//             inv, G_IO_ERROR, G_IO_ERROR_FAILED,
//             "Unsupported LC3 configuration");
//         return;
//     }

//     g_clear_pointer(&ctx->transport_path, g_free);
//     ctx->transport_path = g_strdup(transport);
//     ctx->configured = TRUE;

//     g_message("LC3 locked: 48kHz / 10ms / mono / 80B");

//     g_dbus_method_invocation_return_value(inv, NULL);
// }

// /* ---------------- Acquire ---------------- */

// static void handle_acquire(GDBusMethodInvocation *inv, struct endpoint_ctx *ctx)
// {
//     int fd[2];
//     if (socketpair(AF_UNIX, SOCK_SEQPACKET, 0, fd) < 0) {
//         g_dbus_method_invocation_return_error(inv, G_IO_ERROR, G_IO_ERROR_FAILED, "socketpair failed");
//         return;
//     }

//     g_message("Acquire OK: fd=%d", fd[0]);

//     // fd[1] is what you'll write LC3 frames to
//     g_dbus_method_invocation_return_value(inv, g_variant_new("(hqq)", fd[0], 512, 10000));

//     // Save fd[1] somewhere for streaming
//     ctx->transport_fd = fd[1];
// }

// /* ---------------- Clear / Release ---------------- */

// static void handle_clear_configuration(GDBusMethodInvocation *inv,
//                                        struct endpoint_ctx *ctx)
// {
//     ctx->configured = FALSE;
//     g_clear_pointer(&ctx->transport_path, g_free);
//     g_dbus_method_invocation_return_value(inv, NULL);
// }

// static void handle_release(GDBusMethodInvocation *inv,
//                            struct endpoint_ctx *ctx)
// {
//     (void)ctx;
//     g_dbus_method_invocation_return_value(inv, NULL);
// }

// /* ---------------- Dispatcher ---------------- */

// static void method_call_cb(GDBusConnection *c, const char *s,
//                            const char *path, const char *i,
//                            const char *m, GVariant *p,
//                            GDBusMethodInvocation *inv, void *u)
// {
//     (void)c; (void)s; (void)i; (void)u;

//     struct endpoint_ctx *ctx =
//         strcmp(path, EP_PATH_SOURCE) == 0 ? &ep_source : &ep_sink;

//     if (!strcmp(m, "SelectProperties"))
//         handle_select_properties(inv, p, ctx);
//     else if (!strcmp(m, "SetConfiguration"))
//         handle_set_configuration(inv, p, ctx);
//     else if (!strcmp(m, "Acquire"))
//         handle_acquire(inv, ctx);
//     else if (!strcmp(m, "ClearConfiguration"))
//         handle_clear_configuration(inv, ctx);
//     else if (!strcmp(m, "Release"))
//         handle_release(inv, ctx);
// }

// /* ---------------- Export ---------------- */

// int media_endpoint_export(GDBusConnection *conn)
// {
//     GError *err = NULL;
//     GDBusNodeInfo *node = g_dbus_node_info_new_for_xml(endpoint_xml, &err);
//     if (!node) {
//         g_error("Failed to parse XML: %s", err->message);
//         g_error_free(err);
//         return -1;
//     }

//     static const GDBusInterfaceVTable vt = {
//         .method_call = method_call_cb,
//     };

//     /* Source endpoint */
//     g_dbus_connection_register_object(
//         conn, EP_PATH_SOURCE, node->interfaces[0],
//         &vt, NULL, NULL, NULL);

//     /* Sink endpoint */
//     g_dbus_connection_register_object(
//         conn, EP_PATH_SINK, node->interfaces[0],
//         &vt, NULL, NULL, NULL);

//     g_message("Media endpoints registered (AutoAccept + CIG/CIS enabled)");

//     g_dbus_node_info_unref(node);
//     return 0;
// }


////////this is working code for registering from ourside///////////////////////////////////////////////
// #include <gio/gio.h>
// #include <stdint.h>
// #include <stdio.h>
// #include <string.h>
// #include <unistd.h>
// #include <pthread.h>
// #include <sys/socket.h>

// #define EP_PATH_SOURCE "/local/endpoint/ep0"
// #define EP_PATH_SINK   "/local/endpoint/ep1"
// #define LC3_CODEC_ID   0x06

// /* ---------------- LC3 Config ---------------- */
// struct lc3_cfg {
//     uint8_t  freq;
//     uint8_t  frame_dur;
//     uint16_t frame_len;
//     uint8_t  channels;
// };

// /* ---------------- Endpoint Context ---------------- */
// struct endpoint_ctx {
//     const char *path;
//     char *transport_path;
//     int transport_fd;
//     gboolean configured;
//     gboolean streaming;
//     struct lc3_cfg lc3;
// };

// static struct endpoint_ctx ep_source = { .path = EP_PATH_SOURCE };
// static struct endpoint_ctx ep_sink   = { .path = EP_PATH_SINK };

// /* ---------------- XML ---------------- */
// static const char endpoint_xml[] =
// "<node>"
// " <interface name='org.bluez.MediaEndpoint1'>"
// "  <method name='SelectProperties'>"
// "   <arg name='caps' type='a{sv}' direction='in'/>"
// "   <arg name='properties' type='a{sv}' direction='out'/>"
// "  </method>"
// "  <method name='SetConfiguration'>"
// "   <arg name='transport' type='o' direction='in'/>"
// "   <arg name='properties' type='a{sv}' direction='in'/>"
// "  </method>"
// "  <method name='Acquire'>"
// "   <arg name='fd' type='h' direction='out'/>"
// "   <arg name='mtu' type='q' direction='out'/>"
// "   <arg name='interval' type='q' direction='out'/>"
// "  </method>"
// "  <method name='ClearConfiguration'>"
// "   <arg name='transport' type='o' direction='in'/>"
// "  </method>"
// "  <method name='Release'/>"
// "  <method name='Start'/>"
// "  <method name='Stop'/>"
// " </interface>"
// "</node>";

// /* ---------------- LC3 Dummy Frames ---------------- */
// static void *stream_thread(void *arg)
// {
//     struct endpoint_ctx *ctx = arg;
//     uint8_t frame[80];

//     memset(frame, 0xAA, sizeof(frame)); // dummy LC3 data

//     while (ctx->streaming) {
//         if (ctx->transport_fd > 0) {
//             write(ctx->transport_fd, frame, sizeof(frame));
//         }
//         usleep(10000); // 10ms per frame
//     }

//     return NULL;
// }

// /* ---------------- SelectProperties ---------------- */
// static void handle_select_properties(GDBusMethodInvocation *inv,
//                                      GVariant *params,
//                                      struct endpoint_ctx *ctx)
// {
//     (void)params;

//     static const uint8_t lc3_cfg[] = {
//         0x02, 0x01, 0x80,        // 48 kHz
//         0x02, 0x02, 0x02,        // 10 ms
//         0x02, 0x03, 0x01,        // mono
//         0x03, 0x04, 0x50, 0x00   // 80 bytes
//     };

//     GVariantBuilder props;
//     g_variant_builder_init(&props, G_VARIANT_TYPE("a{sv}"));

//     g_variant_builder_add(&props, "{sv}",
//         "Codec", g_variant_new_byte(LC3_CODEC_ID));

//     g_variant_builder_add(&props, "{sv}",
//         "CodecConfiguration",
//         g_variant_new_fixed_array(G_VARIANT_TYPE_BYTE, lc3_cfg, sizeof(lc3_cfg), 1));

//     /* Add QoS for unicast (required by BlueZ) */
//     GVariantBuilder qos, ucast;
//     g_variant_builder_init(&qos, G_VARIANT_TYPE("a{sv}"));
//     g_variant_builder_init(&ucast, G_VARIANT_TYPE("a{sv}"));

//     // g_variant_builder_add(&ucast, "{sv}", "TargetLatency", g_variant_new_byte(0x01));
//     // g_variant_builder_add(&ucast, "{sv}", "PHY", g_variant_new_byte(0x02));
//     // g_variant_builder_add(&ucast, "{sv}", "Interval", g_variant_new_uint32(10000));
//     // g_variant_builder_add(&ucast, "{sv}", "SDU", g_variant_new_uint16(80));
//     // g_variant_builder_add(&ucast, "{sv}", "Retransmissions", g_variant_new_byte(2));

//     g_variant_builder_add(&ucast, "{sv}", "TargetLatency", g_variant_new_byte(0x02));
// g_variant_builder_add(&ucast, "{sv}", "PHY", g_variant_new_byte(0x02));
// g_variant_builder_add(&ucast, "{sv}", "Interval", g_variant_new_uint16(0x08)); // 10ms / 1.25ms units
// g_variant_builder_add(&ucast, "{sv}", "SDU", g_variant_new_uint16(80));
// g_variant_builder_add(&ucast, "{sv}", "Retransmissions", g_variant_new_byte(2));

//     g_variant_builder_add(&qos, "{sv}", "Unicast", g_variant_builder_end(&ucast));
//     g_variant_builder_add(&props, "{sv}", "QoS", g_variant_builder_end(&qos));

//     /* Metadata empty */
//     GVariantBuilder meta;
//     g_variant_builder_init(&meta, G_VARIANT_TYPE("a{sv}"));
//     g_variant_builder_add(&props, "{sv}", "Metadata", g_variant_builder_end(&meta));

//     g_dbus_method_invocation_return_value(inv, g_variant_new("(a{sv})", &props));
// }

// /* ---------------- SetConfiguration ---------------- */
// static gboolean parse_lc3(const uint8_t *p, size_t len, struct endpoint_ctx *ctx)
// {
//     if (len < 7) return FALSE;
//     ctx->lc3.freq = p[2];
//     ctx->lc3.frame_dur = p[5];
//     ctx->lc3.channels = p[8];
//     ctx->lc3.frame_len = p[11] | (p[12] << 8);
//     return TRUE;
// }

// static void handle_set_configuration(GDBusMethodInvocation *inv,
//                                      GVariant *params,
//                                      struct endpoint_ctx *ctx)
// {
//     const char *transport;
//     GVariant *props, *cfg;
//     const uint8_t *data;
//     gsize len;

//     g_variant_get(params, "(&o@a{sv})", &transport, &props);

//     if (!g_variant_lookup(props, "CodecConfiguration", "@ay", &cfg)) {
//         g_dbus_method_invocation_return_error(inv, G_IO_ERROR, G_IO_ERROR_FAILED, "Missing CodecConfiguration");
//         return;
//     }

//     data = g_variant_get_fixed_array(cfg, &len, 1);
//     if (!parse_lc3(data, len, ctx)) {
//         g_dbus_method_invocation_return_error(inv, G_IO_ERROR, G_IO_ERROR_FAILED, "Unsupported LC3 config");
//         return;
//     }

//     g_clear_pointer(&ctx->transport_path, g_free);
//     ctx->transport_path = g_strdup(transport);
//     ctx->configured = TRUE;

//     g_message("LC3 locked: 48kHz / 10ms / mono / 80B");
//     g_dbus_method_invocation_return_value(inv, NULL);
// }

// /* ---------------- Acquire ---------------- */
// static void handle_acquire(GDBusMethodInvocation *inv, struct endpoint_ctx *ctx)
// {
//     int fds[2];
//     if (socketpair(AF_UNIX, SOCK_SEQPACKET, 0, fds) < 0) {
//         g_dbus_method_invocation_return_error(inv, G_IO_ERROR, G_IO_ERROR_FAILED, "socketpair failed");
//         return;
//     }

//     ctx->transport_fd = fds[1]; // daemon writes here

//     g_message("Acquire OK: fd=%d", fds[0]);

//     g_dbus_method_invocation_return_value(inv, g_variant_new("(hqq)", fds[0], 512, 10000));
// }

// /* ---------------- Clear / Release ---------------- */
// static void handle_clear_configuration(GDBusMethodInvocation *inv,
//                                        struct endpoint_ctx *ctx)
// {
//     ctx->configured = FALSE;
//     ctx->streaming = FALSE;
//     g_clear_pointer(&ctx->transport_path, g_free);
//     if (ctx->transport_fd > 0) close(ctx->transport_fd);
//     ctx->transport_fd = -1;
//     g_dbus_method_invocation_return_value(inv, NULL);
// }

// static void handle_release(GDBusMethodInvocation *inv, struct endpoint_ctx *ctx)
// {
//     (void)ctx;
//     g_dbus_method_invocation_return_value(inv, NULL);
// }

// /* ---------------- Start / Stop ---------------- */
// static void handle_start(GDBusMethodInvocation *inv, struct endpoint_ctx *ctx)
// {
//     if (!ctx->configured) {
//         g_dbus_method_invocation_return_error(inv, G_IO_ERROR, G_IO_ERROR_FAILED, "Endpoint not configured");
//         return;
//     }

//     ctx->streaming = TRUE;
//     g_message("Stream started for %s", ctx->path);

//     pthread_t tid;
//     pthread_create(&tid, NULL, stream_thread, ctx);
//     pthread_detach(tid);

//     g_dbus_method_invocation_return_value(inv, NULL);
// }

// static void handle_stop(GDBusMethodInvocation *inv, struct endpoint_ctx *ctx)
// {
//     ctx->streaming = FALSE;
//     g_message("Stream stopped for %s", ctx->path);
//     g_dbus_method_invocation_return_value(inv, NULL);
// }



// /* ---------------- Dispatcher ---------------- */
// static void method_call_cb(GDBusConnection *c, const char *s,
//                            const char *path, const char *i,
//                            const char *m, GVariant *p,
//                            GDBusMethodInvocation *inv, void *u)
// {
//     (void)c; (void)s; (void)i; (void)u;
//     struct endpoint_ctx *ctx = strcmp(path, EP_PATH_SOURCE) == 0 ? &ep_source : &ep_sink;

//     if (!strcmp(m, "SelectProperties"))
//         handle_select_properties(inv, p, ctx);
//     else if (!strcmp(m, "SetConfiguration"))
//         handle_set_configuration(inv, p, ctx);
//     else if (!strcmp(m, "Acquire"))
//         handle_acquire(inv, ctx);
//     else if (!strcmp(m, "ClearConfiguration"))
//         handle_clear_configuration(inv, ctx);
//     else if (!strcmp(m, "Release"))
//         handle_release(inv, ctx);
//     else if (!strcmp(m, "Start"))
//         handle_start(inv, ctx);
//     else if (!strcmp(m, "Stop"))
//         handle_stop(inv, ctx);
// }

// /* ---------------- Export ---------------- */
// int media_endpoint_export(GDBusConnection *conn)
// {
//     GError *err = NULL;
//     GDBusNodeInfo *node = g_dbus_node_info_new_for_xml(endpoint_xml, &err);
//     if (!node) {
//         g_error("Failed to parse XML: %s", err->message);
//         g_error_free(err);
//         return -1;
//     }

//     static const GDBusInterfaceVTable vt = { .method_call = method_call_cb };

//     g_dbus_connection_register_object(conn, EP_PATH_SOURCE, node->interfaces[0], &vt, NULL, NULL, &err);
//     g_dbus_connection_register_object(conn, EP_PATH_SINK, node->interfaces[0], &vt, NULL, NULL, &err);

//     g_message("Media endpoints registered");
//     g_dbus_node_info_unref(node);
//     return 0;
// }









#include <gio/gio.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <stdio.h>


#define EP_PATH_SOURCE "/local/endpoint/ep0"
#define EP_PATH_SINK   "/local/endpoint/ep1"
#define LC3_CODEC_ID   0x06

struct endpoint_ctx {
    const char *path;
    char *transport;
    int iso_fd;
    gboolean configured;
    gboolean streaming;
};

static struct endpoint_ctx ep_source = { .path = EP_PATH_SOURCE, .iso_fd = -1 };
static struct endpoint_ctx ep_sink   = { .path = EP_PATH_SINK,   .iso_fd = -1 };

/* ---------------- XML ---------------- */
static const char endpoint_xml[] =
"<node>"
" <interface name='org.bluez.MediaEndpoint1'>"
"  <method name='SelectProperties'>"
"   <arg type='a{sv}' direction='in'/>"
"   <arg type='a{sv}' direction='out'/>"
"  </method>"
"  <method name='SetConfiguration'>"
"   <arg type='o' direction='in'/>"
"   <arg type='a{sv}' direction='in'/>"
"  </method>"
"  <method name='Acquire'>"
"   <arg type='h' direction='out'/>"
"   <arg type='q' direction='out'/>"
"   <arg type='q' direction='out'/>"
"  </method>"
"  <method name='ClearConfiguration'>"
"   <arg type='o' direction='in'/>"
"  </method>"
"  <method name='Release'/>"
"  <method name='Start'/>"
"  <method name='Stop'/>"
" </interface>"
"</node>";

/* ---------------- SelectProperties ---------------- */
// static void handle_select_properties(GDBusMethodInvocation *inv)
// {
//     /* LC3 Codec Configuration (LTV) */
//     static const uint8_t lc3_cfg[] = {
//         /* Sampling Frequency: 48 kHz */
//         0x03, 0x01, 0x80, 0x00,

//         /* Frame Duration: 10 ms */
//         0x02, 0x02, 0x01,

//         /* Channel Allocation: Mono */
//         0x02, 0x03, 0x01,

//         /* Octets per Frame: 40 */
//         0x05, 0x04, 0x28, 0x00, 0x28, 0x00,
//     };

//     GVariantBuilder reply;
//     GVariantBuilder qos;

//     g_variant_builder_init(&reply, G_VARIANT_TYPE("a{sv}"));
//     g_variant_builder_init(&qos,   G_VARIANT_TYPE("a{sv}"));

//     /* ---------- QoS (THIS CREATES ASCS STATUS CONFIG) ---------- */

//     g_variant_builder_add(&qos, "{sv}", "Framing",
//         g_variant_new_byte(0x00));   /* Unframed */

//     g_variant_builder_add(&qos, "{sv}", "PHY",
//         g_variant_new_byte(0x02));   /* 2M PHY */

//     g_variant_builder_add(&qos, "{sv}", "Retransmissions",
//         g_variant_new_byte(2));

//     g_variant_builder_add(&qos, "{sv}", "Latency",
//         g_variant_new_uint16(10));

//     g_variant_builder_add(&qos, "{sv}", "PresentationDelay",
//         g_variant_new("(uu)", 3000, 60000));

//     g_variant_builder_add(&qos, "{sv}", "PreferredPresentationDelay",
//         g_variant_new("(uu)", 3000, 40000));

//     /* ---------- Configuration ---------- */

//     g_variant_builder_add(
//         &reply,
//         "{sv}",
//         "Configuration",
//         g_variant_new_fixed_array(
//             G_VARIANT_TYPE_BYTE,
//             lc3_cfg,
//             sizeof(lc3_cfg),
//             1));

//     g_variant_builder_add(
//         &reply,
//         "{sv}",
//         "QoS",
//         g_variant_builder_end(&qos));

//     g_dbus_method_invocation_return_value(
//         inv,
//         g_variant_new("(@a{sv})",
//             g_variant_builder_end(&reply)));
// }

// static void handle_select_properties(GDBusMethodInvocation *inv)
// {
//     static const uint8_t lc3_caps[] = {
//         0x03, 0x01, 0x80,              /* 48 kHz */

//         0x02, 0x02, 0x02,              /* 10 ms */

//         0x02, 0x03, 0x01,              /* mono */

//         0x03, 0x04, 0x50, 0x00,        /* frame len */

//         0x02, 0x05, 0x01               /* max SDU */
//     };

//     GVariantBuilder props, qos;

//     g_variant_builder_init(&props, G_VARIANT_TYPE("a{sv}"));
//     g_variant_builder_init(&qos,   G_VARIANT_TYPE("a{sv}"));

//     /* ---------- QoS (MATCHES parse_ucast_qos EXACTLY) ---------- */

//     g_variant_builder_add(&qos, "{sv}", "Interval",
//         g_variant_new_uint32(10000));      /* 10 ms */

//     g_variant_builder_add(&qos, "{sv}", "Framing",
//         g_variant_new_byte(0x00));          /* Unframed */

//     g_variant_builder_add(&qos, "{sv}", "PHY",
//         g_variant_new_byte(0x02));          /* LE 2M */

//     g_variant_builder_add(&qos, "{sv}", "SDU",
//         g_variant_new_uint16(120));         /* safe LC3 SDU */

//     g_variant_builder_add(&qos, "{sv}", "Retransmissions",
//         g_variant_new_byte(2));

//     g_variant_builder_add(&qos, "{sv}", "Latency",
//         g_variant_new_uint16(10));

//     g_variant_builder_add(&qos, "{sv}", "PresentationDelay",
//         g_variant_new_uint32(3000));

//     g_variant_builder_add(&qos, "{sv}", "TargetLatency",
//         g_variant_new_byte(1));             /* LOW */

//     /* ---------- Properties ---------- */

//     g_variant_builder_add(&props, "{sv}", "QoS",
//         g_variant_builder_end(&qos));

//     g_variant_builder_add(&props, "{sv}", "Capabilities",
//         g_variant_new_fixed_array(
//             G_VARIANT_TYPE_BYTE,
//             lc3_caps,
//             sizeof(lc3_caps),
//             1));

//     g_dbus_method_invocation_return_value(
//         inv,
//         g_variant_new("(@a{sv})",
//             g_variant_builder_end(&props)));
// }

//WORKING SELECT_PROPERTIES:===========================5:35PM
// static void handle_select_properties(
//         GDBusMethodInvocation *inv,
//         GVariant *p)
// {
//     (void)p;   // if not used

//     GVariantBuilder props;
//     GVariantBuilder caps;


//     g_variant_builder_init(&props, G_VARIANT_TYPE("a{sv}"));
//     g_variant_builder_init(&caps, G_VARIANT_TYPE("ay"));

//     /* Sampling Frequency 48kHz          */
//     /* Length = 3 (type + 2 bytes value) */
//     g_variant_builder_add(&caps, "y", 0x02); //03
//     g_variant_builder_add(&caps, "y", 0x01);
//     g_variant_builder_add(&caps, "y", 0x08);
//     // g_variant_builder_add(&caps, "y", 0x00);

//     /* ---------------------------------- */
//     /* Frame Duration 10ms + preferred   */
//     /* Value = 0x22 (1 byte)             */
//     /* Length = 2 (type + 1 byte value)  */
//     g_variant_builder_add(&caps, "y", 0x02);
//     g_variant_builder_add(&caps, "y", 0x02);
//     g_variant_builder_add(&caps, "y", 0x01); //22 //02


// /* Audio Channel Allocation = Front Left */
// g_variant_builder_add(&caps, "y", 0x05);  // length = type + 4 bytes
// g_variant_builder_add(&caps, "y", 0x03);  // type

// g_variant_builder_add(&caps, "y", 0x01);  // FL (bit 0)
// g_variant_builder_add(&caps, "y", 0x00);
// g_variant_builder_add(&caps, "y", 0x00);
// g_variant_builder_add(&caps, "y", 0x00);

//     /* ---------------------------------- */
//     /* Frame Length 40–155               */
//     /* Value = 4 bytes                   */
//     /* Length = 5 (type + 4 value bytes) */
//     g_variant_builder_add(&caps, "y", 0x03);  //05
//     g_variant_builder_add(&caps, "y", 0x04);
//     g_variant_builder_add(&caps, "y", 0x9b);  //28
//     g_variant_builder_add(&caps, "y", 0x00);
//     // g_variant_builder_add(&caps, "y", 0x9b);
//     // g_variant_builder_add(&caps, "y", 0x00);

//     /* ---------------------------------- */
//     /* Max SDU = 1                       */
//     /* Length = 2                        */
//     g_variant_builder_add(&caps, "y", 0x02);
//     g_variant_builder_add(&caps, "y", 0x05);
//     g_variant_builder_add(&caps, "y", 0x01);
    
//     g_variant_builder_add(&props, "{sv}",
//         "Capabilities",
//         g_variant_builder_end(&caps));
    
//     g_dbus_method_invocation_return_value(
//         inv,
//         g_variant_new("(a{sv})", &props));


// }

static void handle_select_properties(GDBusMethodInvocation *inv)
{
    /* LC3 Codec Configuration (LTV) */
    static const uint8_t lc3_cfg[] = {
        /* Sampling Frequency: 48 kHz */
        0x02, 0x01, 0x08, 
        /* Frame Duration: 10 ms */
        0x02, 0x02, 0x01,
        /* Channel Allocation: Mono */
        0x05, 0x03, 0x01, 0X00, 0X00, 0X00,

        /* Octets per Frame: 40 */
        0x03, 0x04, 0x9B, 0x00,

        0x02, 0x05, 0x01
    };

    GVariantBuilder reply;
    GVariantBuilder qos;

    g_variant_builder_init(&reply, G_VARIANT_TYPE("a{sv}"));
    g_variant_builder_init(&qos,   G_VARIANT_TYPE("a{sv}"));

    /* ---------- QoS (THIS CREATES ASCS STATUS CONFIG) ---------- */

    g_variant_builder_add(&qos, "{sv}", "Framing",
        g_variant_new_byte(0x00));   /* Unframed */

    g_variant_builder_add(&qos, "{sv}", "PHY",
        g_variant_new_byte(0x02));   /* 2M PHY */

    g_variant_builder_add(&qos, "{sv}", "Retransmissions",
        g_variant_new_byte(2));

    g_variant_builder_add(&qos, "{sv}", "MaximumLatency",
        g_variant_new_uint16(10));

    // g_variant_builder_add(&qos, "{sv}", "PresentationDelay",
    //     g_variant_new("(uu)", 3000, 60000));

    // g_variant_builder_add(&qos, "{sv}", "PreferredPresentationDelay",
    //     g_variant_new("(uu)", 3000, 40000));

    g_variant_builder_add(&qos, "{sv}", "MimimumDelay",
    g_variant_new_uint32(3000));  // 40 ms

    g_variant_builder_add(&qos, "{sv}", "MaximumDelay",
    g_variant_new_uint32(60000));  // 40 ms

    g_variant_builder_add(&qos, "{sv}", "PreferredMimimumDelay",
    g_variant_new_uint32(3000));  // 40 ms

    g_variant_builder_add(&qos, "{sv}", "PreferredMaximumDelay",
    g_variant_new_uint32(40000));


    /* ---------- Configuration ---------- */

    g_variant_builder_add(
        &reply,
        "{sv}",
        "Capabilities",
        g_variant_new_fixed_array(
            G_VARIANT_TYPE_BYTE,
            lc3_cfg,
            sizeof(lc3_cfg),
            sizeof(uint8_t)));
    
    // printf("lc3_cfg size = %lu\n", sizeof(lc3_cfg));


    g_variant_builder_add(
        &reply,
        "{sv}",
        "QoS",
        g_variant_builder_end(&qos));

    g_dbus_method_invocation_return_value(
        inv,
        g_variant_new("(@a{sv})",
            g_variant_builder_end(&reply)));
}


    // GVariant *properties = NULL;


        //Chandu editting 4:41 pm
    // /* ISO interval 10ms */
    // g_variant_builder_add(&qos, "{sv}",
    //     "Interval", g_variant_new_uint32(10000));

    // /* Unframed */
    // g_variant_builder_add(&qos, "{sv}",
    //     "Framing", g_variant_new_byte(0x00));

    // /* 2M PHY */
    // g_variant_builder_add(&qos, "{sv}",
    //     "PHY", g_variant_new_byte(0x02));

    // /* SDU size */
    // g_variant_builder_add(&qos, "{sv}",
    //     "SDU", g_variant_new_uint16(155));

    // /* Retransmissions */
    // g_variant_builder_add(&qos, "{sv}",
    //     "Retransmissions", g_variant_new_byte(2));

    // /* Transport latency */
    // g_variant_builder_add(&qos, "{sv}",
    //     "Latency", g_variant_new_uint16(10));

    // /* Presentation delay range */
    // g_variant_builder_add(&qos, "{sv}",
    //     "PresentationDelayMin", g_variant_new_uint32(3000));

    // g_variant_builder_add(&qos, "{sv}",
    //     "PresentationDelayMax", g_variant_new_uint32(60000));

    // g_variant_builder_add(&qos, "{sv}",
    //     "PreferredPresentationDelayMin", g_variant_new_uint32(3000));

    // g_variant_builder_add(&qos, "{sv}",
    //     "PreferredPresentationDelayMax", g_variant_new_uint32(40000));

    // g_dbus_method_invocation_return_value(
    //     inv,
    //     g_variant_new("(a{sv})", &qos));


//     g_variant_builder_init(&qos, G_VARIANT_TYPE("a{sv}"));

//     /* ISO interval: 10 ms (in microseconds) */
//     g_variant_builder_add(&qos, "{sv}",
//         "Interval", g_variant_new_uint32(10000));

//     /* Unframed */
//     g_variant_builder_add(&qos, "{sv}",
//         "Framing", g_variant_new_byte(0x00));

//     /* 2M PHY */
//     g_variant_builder_add(&qos, "{sv}",
//         "PHY", g_variant_new_byte(0x02));

//     /* SDU size = 120 bytes */
//     g_variant_builder_add(&qos, "{sv}",
//         "SDU", g_variant_new_uint16(120));

//     /* Retransmissions */
//     g_variant_builder_add(&qos, "{sv}",
//         "Retransmissions", g_variant_new_byte(2));

//     /*  THIS WAS MISSING */
//     g_variant_builder_add(&qos, "{sv}",
//         "Latency", g_variant_new_uint16(10));

//     /* Presentation delay */
//     g_variant_builder_add(&qos, "{sv}",
//         "PresentationDelay", g_variant_new_uint32(40000));

//     g_dbus_method_invocation_return_value(
//         inv,
//         g_variant_new("(a{sv})", &qos));



static void handle_set_configuration(
        GDBusMethodInvocation *inv,
        GVariant *params,
        struct endpoint_ctx *ctx)
{
    const char *transport;
    GVariant *properties = NULL;
    // GVariantBuilder qos;
    (void)inv;
    g_variant_get(params, "(&o@a{sv})", &transport, &properties);

    g_clear_pointer(&ctx->transport, g_free);
    ctx->transport = g_strdup(transport);
    ctx->configured = TRUE;

    // g_variant_builder_init(&qos, G_VARIANT_TYPE("a{sv}"));

    // /* ISO interval 10ms */
    // g_variant_builder_add(&qos, "{sv}",
    //     "Interval", g_variant_new_uint32(10000));

    // /* Unframed */
    // g_variant_builder_add(&qos, "{sv}",
    //     "Framing", g_variant_new_byte(0x00));

    // /* 2M PHY */
    // g_variant_builder_add(&qos, "{sv}",
    //     "PHY", g_variant_new_byte(0x02));

    // /* SDU size */
    // g_variant_builder_add(&qos, "{sv}",
    //     "SDU", g_variant_new_uint16(120));

    // /* Retransmissions */
    // g_variant_builder_add(&qos, "{sv}",
    //     "Retransmissions", g_variant_new_byte(2));

    // /* Transport latency */
    // g_variant_builder_add(&qos, "{sv}",
    //     "Latency", g_variant_new_uint16(10));

    // /* Presentation delay range */
    // g_variant_builder_add(&qos, "{sv}",
    //     "PresentationDelayMin", g_variant_new_uint32(3000));

    // g_variant_builder_add(&qos, "{sv}",
    //     "PresentationDelayMax", g_variant_new_uint32(60000));

    // g_variant_builder_add(&qos, "{sv}",
    //     "PreferredPresentationDelayMin", g_variant_new_uint32(3000));

    // g_variant_builder_add(&qos, "{sv}",
    //     "PreferredPresentationDelayMax", g_variant_new_uint32(40000));

    // g_dbus_method_invocation_return_value(
    //     inv,
    //     g_variant_new("(a{sv})", &qos));

    // g_variant_unref(properties);
}




    
    // /* Build QoS response */
    // g_variant_builder_init(&b, G_VARIANT_TYPE("a{sv}"));

    // g_variant_builder_add(&b, "{sv}",
    //     "Framing", g_variant_new_byte(0x00));   /* Unframed */
    
    // g_variant_builder_add(&b, "{sv}",
    //     "PHY", g_variant_new_byte(0x02));       /* 2M */
    
    // g_variant_builder_add(&b, "{sv}",
    //     "Retransmissions", g_variant_new_byte(2));
    
    // g_variant_builder_add(&b, "{sv}",
    //     "Latency", g_variant_new_uint16(10));
    
    // g_variant_builder_add(&b, "{sv}",
    //     "PresentationDelayMin", g_variant_new_uint32(3000));
    
    // g_variant_builder_add(&b, "{sv}",
    //     "PresentationDelayMax", g_variant_new_uint32(60000));

    // g_variant_builder_add(&b, "{sv}",
    //     "PreferredPresentationDelayMin", g_variant_new_uint32(3000));
    
    // g_variant_builder_add(&b, "{sv}",
    //     "PreferredPresentationDelayMax", g_variant_new_uint32(40000));
    
    // g_dbus_method_invocation_return_value(
    //     inv,
    //     g_variant_new("(a{sv})", &b));

    // g_variant_unref(properties);
// }


/* ---------------- SetConfiguration ---------------- */
// static void handle_set_configuration(GDBusMethodInvocation *inv,
//                                      GVariant *params,
//                                      struct endpoint_ctx *ctx)
// {
//     const char *transport;
//     GVariant *props;

//     g_variant_get(params, "(&o@a{sv})", &transport, &props);

//     g_free(ctx->transport);
//     ctx->transport = g_strdup(transport);
//     ctx->configured = TRUE;

//     g_message("Configured %s", transport);
//     g_dbus_method_invocation_return_value(inv, NULL);
// }



/* ---------------- Acquire ---------------- */
static void handle_acquire(GDBusMethodInvocation *inv,
    struct endpoint_ctx *ctx)
    {
    int fds[2];

    if (socketpair(AF_UNIX, SOCK_SEQPACKET, 0, fds) < 0) {
        g_dbus_method_invocation_return_error(inv,
            G_IO_ERROR, G_IO_ERROR_FAILED, "socketpair failed");
        return;
    }

    ctx->iso_fd = fds[1];

    g_dbus_method_invocation_return_value(inv,
        g_variant_new("(hqq)", fds[0], 80, 10000));
}


/* ---------------- Start / Stop ---------------- */
static void handle_start(GDBusMethodInvocation *inv,
                         struct endpoint_ctx *ctx)
{
    ctx->streaming = TRUE;
    g_message("Stream started %s", ctx->path);
    g_dbus_method_invocation_return_value(inv, NULL);
}

static void handle_stop(GDBusMethodInvocation *inv,
                        struct endpoint_ctx *ctx)
{
    ctx->streaming = FALSE;
    g_message("Stream stopped %s", ctx->path);
    g_dbus_method_invocation_return_value(inv, NULL);
}

/* ---------------- Clear / Release ---------------- */
static void handle_clear(GDBusMethodInvocation *inv,
                         struct endpoint_ctx *ctx)
{
    ctx->configured = FALSE;
    ctx->streaming = FALSE;
    if (ctx->iso_fd >= 0) close(ctx->iso_fd);
    ctx->iso_fd = -1;

    g_clear_pointer(&ctx->transport, g_free);
    g_dbus_method_invocation_return_value(inv, NULL);
}

static void handle_release(GDBusMethodInvocation *inv)
{
    g_dbus_method_invocation_return_value(inv, NULL);
}

/* ---------------- Dispatcher ---------------- */
static void method_call_cb(GDBusConnection *c,
                           const char *s,
                           const char *path,
                           const char *i,
                           const char *m,
                           GVariant *p,
                           GDBusMethodInvocation *inv,
                           void *u)
{
    (void)c; (void)s; (void)i; (void)u;

    struct endpoint_ctx *ctx =
        strcmp(path, EP_PATH_SOURCE) == 0 ? &ep_source : &ep_sink;

    if (!strcmp(m, "SelectProperties"))
        handle_select_properties(inv);
    else if (!strcmp(m, "SetConfiguration"))
        handle_set_configuration(inv, p, ctx);
    else if (!strcmp(m, "Acquire"))
        handle_acquire(inv, ctx);
    else if (!strcmp(m, "Start"))
        handle_start(inv, ctx);
    else if (!strcmp(m, "Stop"))
        handle_stop(inv, ctx);
    else if (!strcmp(m, "ClearConfiguration"))
        handle_clear(inv, ctx);
    else if (!strcmp(m, "Release"))
        handle_release(inv);
}

/* ---------------- Export ---------------- */
int media_endpoint_export(GDBusConnection *conn)
{
    GDBusNodeInfo *node;
    GError *err = NULL;

    node = g_dbus_node_info_new_for_xml(endpoint_xml, &err);
    if (!node)
        return -1;

    static const GDBusInterfaceVTable vt = {
        .method_call = method_call_cb
    };

    g_dbus_connection_register_object(conn, EP_PATH_SOURCE,
        node->interfaces[0], &vt, NULL, NULL, NULL);

    g_dbus_connection_register_object(conn, EP_PATH_SINK,
        node->interfaces[0], &vt, NULL, NULL, NULL);

    g_dbus_node_info_unref(node);
    g_message("LE Audio endpoints registered");
    return 0;
}

