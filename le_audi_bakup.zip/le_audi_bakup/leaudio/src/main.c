// /////////////working//////////////////////
// #include <gio/gio.h>
// #include <stdio.h>

// #include "bluez-device.h"
// #include "bluez-media-endpoint.h"
// #include "bluez5-dbus.h"


// int main(void)
// {
//     GDBusConnection *bus;
//     GMainLoop *loop;

//     bus = g_bus_get_sync(G_BUS_TYPE_SYSTEM, NULL, NULL);
//     if (!bus) {
//         g_printerr("Failed to connect to system bus\n");
//         return 1;
//     }

//     /* 1. Export MediaEndpoint1 objects */
//     media_endpoint_export(bus);

//     /* 2. Register PAC source + sink with BlueZ */
//     bluez_register_endpoints(bus);

//     /* 3. Start device monitoring */
//     bluez_device_init(bus);

//     g_print("[LEAUDIO] daemon running\n");

//     loop = g_main_loop_new(NULL, FALSE);
//     g_main_loop_run(loop);

//     return 0;
// }


#include <gio/gio.h>
#include "bluez-media-endpoint.h"
#include "bluez5-dbus.h"

int main(void)
{
    GMainLoop *loop;
    GDBusConnection *conn;

    conn = g_bus_get_sync(G_BUS_TYPE_SYSTEM, NULL, NULL);
    if (!conn)
        return 1;

    media_endpoint_export(conn);
    bluez_register_endpoints(conn);

    g_message("[LEAUDIO] daemon running");

    loop = g_main_loop_new(NULL, FALSE);
    g_main_loop_run(loop);
    return 0;
}
