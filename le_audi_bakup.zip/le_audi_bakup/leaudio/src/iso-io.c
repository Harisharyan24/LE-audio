#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>

#include "iso-io.h"

/* -------------------------
 * Internal stream object
 * ------------------------- */
struct stream {
	struct spa_bt_iso_io io;

	spa_bt_iso_io_pull_t pull;
	struct spa_bt_decode_buffer *source_buf;

	uint64_t rx_pos;
};

/* -------------------------
 * Create
 * ------------------------- */
struct spa_bt_iso_io *
spa_bt_iso_io_create(struct spa_bt_transport *t)
{
	(void)t;

	struct stream *s = calloc(1, sizeof(*s));
	if (!s)
		return NULL;

	s->io.duration = 10000 * 1000; /* default 10 ms */
	s->io.resync = true;

	return &s->io;
}

/* -------------------------
 * Attach (same group, new stream)
 * ------------------------- */
struct spa_bt_iso_io *
spa_bt_iso_io_attach(struct spa_bt_iso_io *io,
                     struct spa_bt_transport *t)
{
	(void)io;
	return spa_bt_iso_io_create(t);
}

/* -------------------------
 * Destroy
 * ------------------------- */
void spa_bt_iso_io_destroy(struct spa_bt_iso_io *io)
{
	struct stream *s =
		(struct stream *)((char *)io - offsetof(struct stream, io));

	free(s);
}

/* -------------------------
 * Set callback
 * ------------------------- */
void spa_bt_iso_io_set_cb(struct spa_bt_iso_io *io,
                          spa_bt_iso_io_pull_t pull,
                          void *user_data)
{
	struct stream *s =
		(struct stream *)((char *)io - offsetof(struct stream, io));

	s->pull = pull;
	io->user_data = user_data;

	io->resync = true;
	io->size = 0;
}

/* -------------------------
 * RX buffer
 * ------------------------- */
void spa_bt_iso_io_set_source_buffer(struct spa_bt_iso_io *io,
                                     struct spa_bt_decode_buffer *buffer)
{
	struct stream *s =
		(struct stream *)((char *)io - offsetof(struct stream, io));

	s->source_buf = buffer;
	s->rx_pos = 0;
}

/* -------------------------
 * RX packet timestamping
 * ------------------------- */
int64_t spa_bt_iso_io_recv(struct spa_bt_iso_io *io, int64_t now)
{
	struct stream *s =
		(struct stream *)((char *)io - offsetof(struct stream, io));

	if (s->rx_pos == 0) {
		io->now = now;
		s->rx_pos = 1;
		return now;
	}

	int64_t t = io->now + io->duration * s->rx_pos;
	s->rx_pos++;

	return t;
}

/* -------------------------
 * RX sync correction (stub)
 * ------------------------- */
void spa_bt_iso_io_check_rx_sync(struct spa_bt_iso_io *io,
                                 uint64_t position)
{
	(void)position;

	if (io->need_resync) {
		io->resync = true;
		io->need_resync = false;
	}
}

