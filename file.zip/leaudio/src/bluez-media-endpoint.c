// // // // // // ////////////segmentation fault in bluez///////////////////

// // // // #include "bluez-media-endpoint.h"
// // // // #include <gio/gio.h>
// // // // #include <string.h>
// // // // #include <stdint.h>

// // // // /* Endpoint object paths */
// // // // #define EP_PATH_SOURCE "/local/endpoint/ep0"
// // // // #define EP_PATH_SINK   "/local/endpoint/ep1"

// // // // /* ---------------------------------------------------- */
// // // // /* Endpoint runtime state (per endpoint)                */
// // // // /* ---------------------------------------------------- */

// // // // struct endpoint_ctx {
// // // //     const char *path;
// // // //     char *transport_path;

// // // //     GVariant *codec_config;
// // // //     GVariant *qos;
// // // // };

// // // // static struct endpoint_ctx ep_source = {
// // // //     .path = EP_PATH_SOURCE,
// // // // };

// // // // static struct endpoint_ctx ep_sink = {
// // // //     .path = EP_PATH_SINK,
// // // // };

// // // // /* ---------------------------------------------------- */
// // // // /* Forward declarations                                 */
// // // // /* ---------------------------------------------------- */

// // // // static void handle_select_properties(GDBusMethodInvocation *invocation,
// // // //                                      GVariant *parameters,
// // // //                                      struct endpoint_ctx *ctx);

// // // // static void handle_set_configuration(GDBusMethodInvocation *invocation,
// // // //                                      GVariant *parameters,
// // // //                                      struct endpoint_ctx *ctx);

// // // // // static void handle_clear_configuration(GDBusMethodInvocation *invocation,
// // // // //                                        GVariant *parameters,
// // // // //                                        struct endpoint_ctx *ctx);
// // // // static void handle_clear_configuration(GDBusMethodInvocation *invocation,
// // // //                                        struct endpoint_ctx *ctx);

// // // // static void handle_release(GDBusMethodInvocation *invocation,
// // // //                            struct endpoint_ctx *ctx);

// // // // /* ---------------------------------------------------- */
// // // // /* MediaEndpoint1 introspection XML                     */
// // // // /* ---------------------------------------------------- */

// // // // static const char endpoint_xml[] =
// // // // "<node>"
// // // // " <interface name='org.bluez.MediaEndpoint1'>"
// // // // "  <method name='SelectProperties'>"
// // // // "   <arg name='caps' type='a{sv}' direction='in'/>"
// // // // "   <arg name='properties' type='a{sv}' direction='out'/>"
// // // // "  </method>"
// // // // "  <method name='SetConfiguration'>"
// // // // "   <arg name='transport' type='o' direction='in'/>"
// // // // "   <arg name='properties' type='a{sv}' direction='in'/>"
// // // // "  </method>"
// // // // "  <method name='ClearConfiguration'>"
// // // // "   <arg name='transport' type='o' direction='in'/>"
// // // // "  </method>"
// // // // "  <method name='Release'/>"
// // // // " </interface>"
// // // // "</node>";

// // // // /* ---------------------------------------------------- */
// // // // /* SelectProperties (ALREADY WORKING – DO NOT TOUCH)    */
// // // // /* ---------------------------------------------------- */
// // // // static void handle_select_properties(GDBusMethodInvocation *invocation,
// // // //                                      GVariant *parameters,
// // // //                                      struct endpoint_ctx *ctx)
// // // // {
// // // //     GVariant *caps;
// // // //     g_variant_get(parameters, "(@a{sv})", &caps);

// // // //     g_message("[Endpoint %s] SelectProperties", ctx->path);

// // // //     /* LC3: 48 kHz, 10 ms, mono */
// // // //     static const uint8_t lc3_config[] = {
// // // //         0x02, 0x01, 0x80,        /* Sampling Frequency = 48 kHz */
// // // //         0x02, 0x02, 0x02,        /* Frame Duration = 10 ms */
// // // //         0x02, 0x03, 0x01,        /* Channel Count = 1 */
// // // //         0x03, 0x04, 0x78, 0x00   /* Frame Length = 120 bytes (safe MIN) */
// // // //     };

// // // //     GVariantBuilder props;
// // // //     g_variant_builder_init(&props, G_VARIANT_TYPE("a{sv}"));

// // // //     g_variant_builder_add(&props, "{sv}",
// // // //         "Codec", g_variant_new_byte(0x06)); /* LC3 */

// // // //     g_variant_builder_add(&props, "{sv}",
// // // //         "CodecConfiguration",
// // // //         g_variant_new_fixed_array(G_VARIANT_TYPE_BYTE,
// // // //                                   lc3_config,
// // // //                                   sizeof(lc3_config),
// // // //                                   sizeof(uint8_t)));

// // // //     /* Mono audio location */
// // // //     g_variant_builder_add(&props, "{sv}",
// // // //         "AudioLocations", g_variant_new_uint32(0x00000001));

// // // //     /* Context = Media */
     
// // // //     guint16 context = 0x0001;
// // // //      g_variant_builder_add(&props, "{sv}",
// // // //          "Context",
// // // //          g_variant_new_fixed_array(G_VARIANT_TYPE_UINT16,
// // // //                                    &context, 1, sizeof(guint16)));

// // // //  /* ---------------- Metadata (REQUIRED for Nordic) ---------------- */

// // // //     GVariantBuilder metadata;
// // // //     g_variant_builder_init(&metadata, G_VARIANT_TYPE("ay"));

// // // //     /* LTV:
// // // //      * len=2, type=0x01 (Context Type), value=0x0001 (Media)
// // // //      */
// // // //     const uint8_t meta[] = { 0x02, 0x01, 0x01, 0x00 };

// // // //     for (size_t i = 0; i < sizeof(meta); i++)
// // // //         g_variant_builder_add(&metadata, "y", meta[i]);

// // // //     g_variant_builder_add(&props, "{sv}",
// // // //         "Metadata", g_variant_builder_end(&metadata));


// // // //     /* QoS — aligned with Zephyr defaults */
// // // //     GVariantBuilder qos;
// // // //     g_variant_builder_init(&qos, G_VARIANT_TYPE("a{sv}"));

// // // //     g_variant_builder_add(&qos, "{sv}", "Framing", g_variant_new_byte(0));
// // // //     g_variant_builder_add(&qos, "{sv}", "PHY", g_variant_new_byte(2)); /* 1M */
// // // //     g_variant_builder_add(&qos, "{sv}", "SDU", g_variant_new_uint16(120));
  

    
    
// // // //     g_variant_builder_add(&qos, "{sv}", "Retransmissions", g_variant_new_byte(2));
// // // //     g_variant_builder_add(&qos, "{sv}", "Latency", g_variant_new_uint16(20));
    
// // // //     g_variant_builder_add(&qos, "{sv}", "TargetLatency", g_variant_new_byte(1));
    

// // // //     g_variant_builder_add(&props, "{sv}",
// // // //         "QoS", g_variant_builder_end(&qos));

// // // //     g_dbus_method_invocation_return_value(
// // // //         invocation,
// // // //         g_variant_new("(@a{sv})", g_variant_builder_end(&props)));

// // // //     g_variant_unref(caps);
// // // // }



// // // // /* ---------------------------------------------------- */
// // // // /* SetConfiguration – MAIN WORK STARTS HERE              */
// // // // /* ---------------------------------------------------- */


// // // // // static void handle_set_configuration(GDBusMethodInvocation *invocation,
// // // // //                                      GVariant *parameters,
// // // // //                                      struct endpoint_ctx *ctx)
// // // // // {
// // // // //     const char *transport = NULL;
// // // // //     GVariant *props = NULL;
// // // // //     g_variant_get(parameters, "(&o@a{sv})", &transport, &props);

// // // // //     g_message("[Endpoint %s] SetConfiguration transport=%s", ctx->path, transport);

// // // // //     g_clear_pointer(&ctx->transport_path, g_free);
// // // // //     ctx->transport_path = g_strdup(transport);

// // // // //     g_clear_pointer(&ctx->codec_config, g_variant_unref);
// // // // //     g_clear_pointer(&ctx->qos, g_variant_unref);

// // // // //     GVariant *tmp;

// // // // //     if (g_variant_lookup(props, "CodecConfiguration", "@ay", &tmp))
// // // // //         ctx->codec_config = g_variant_ref(tmp);  // REF before storing

// // // // //     if (g_variant_lookup(props, "QoS", "@a{sv}", &tmp))
// // // // //         ctx->qos = g_variant_ref(tmp);          // REF before storing

// // // // //     g_dbus_method_invocation_return_value(invocation, NULL);
// // // // //     g_variant_unref(props);
// // // // // }


// // // // // static void handle_set_configuration(GDBusMethodInvocation *invocation,
// // // // //                                      GVariant *parameters,
// // // // //                                      struct endpoint_ctx *ctx)
// // // // // {
// // // // //     const char *transport = NULL;
// // // // //     GVariant *props = NULL;

// // // // //     /* Signature: (object-path, dict<string,variant>) */
// // // // //     g_variant_get(parameters, "(&o@a{sv})", &transport, &props);

// // // // //     g_message("[Endpoint %s] SetConfiguration", ctx->path);
// // // // //     g_message("  Transport: %s", transport);

// // // // //     /* Save transport path */
// // // // //     g_clear_pointer(&ctx->transport_path, g_free);
// // // // //     ctx->transport_path = g_strdup(transport);

// // // // //     /* -------- CodecConfiguration -------- */
// // // // //     g_clear_pointer(&ctx->codec_config, g_variant_unref);

// // // // //     if (g_variant_lookup(props, "CodecConfiguration", "@ay",
// // // // //                           &ctx->codec_config)) {
// // // // //         g_message("  CodecConfiguration received (%zu bytes)",
// // // // //                   g_variant_n_children(ctx->codec_config));
// // // // //     } else {
// // // // //         g_warning("  CodecConfiguration missing (still accepting)");
// // // // //     }

// // // // //     /* -------- QoS (opaque, DO NOT PARSE) -------- */
// // // // //     g_clear_pointer(&ctx->qos, g_variant_unref);

// // // // //     if (g_variant_lookup(props, "QoS", "@a{sv}", &ctx->qos)) {
// // // // //         g_message("  QoS received (opaque)");
// // // // //     } else {
// // // // //         g_warning("  QoS missing (still accepting)");
// // // // //     }

// // // // //     /* VERY IMPORTANT:
// // // // //      * Do NOT validate
// // // // //      * Do NOT reject
// // // // //      * Do NOT modify
// // // // //      */
// // // // //     g_dbus_method_invocation_return_value(invocation, NULL);

// // // // //     g_variant_unref(props);
// // // // // }


// // // // static void handle_set_configuration(GDBusMethodInvocation *invocation,
// // // //                                      GVariant *parameters,
// // // //                                      struct endpoint_ctx *ctx)
// // // // {
// // // //     const char *transport = NULL;
// // // //     GVariant *props = NULL;

// // // //     g_variant_get(parameters, "(&o@a{sv})", &transport, &props);

// // // //     g_message("[Endpoint %s] SetConfiguration", ctx->path);
// // // //     g_message("  Transport: %s", transport);
// // // //     g_message("  Properties: %s", g_variant_print(props, TRUE));

// // // //     /* Save transport path */
// // // //     g_free(ctx->transport_path);
// // // //     ctx->transport_path = g_strdup(transport);

// // // //     /* Extract CodecConfiguration */
// // // //     if (ctx->codec_config)
// // // //         g_variant_unref(ctx->codec_config);

// // // //     g_variant_lookup(props, "CodecConfiguration", "@ay", &ctx->codec_config);

// // // //     if (ctx->codec_config)
// // // //         g_message("  CodecConfiguration stored");

// // // //     /* Extract QoS */
// // // //     if (ctx->qos)
// // // //         g_variant_unref(ctx->qos);

// // // //     g_variant_lookup(props, "QoS", "@a{sv}", &ctx->qos);

// // // //     if (ctx->qos)
// // // //         g_message("  QoS stored: %s", g_variant_print(ctx->qos, TRUE));

// // // //     /* IMPORTANT: tell BlueZ we ACCEPT the configuration */
// // // //     g_dbus_method_invocation_return_value(invocation, NULL);

// // // //     g_variant_unref(props);
// // // // }

// // // // /* ---------------------------------------------------- */
// // // // /* ClearConfiguration                                   */
// // // // /* ---------------------------------------------------- */

// // // // // static void handle_clear_configuration(GDBusMethodInvocation *invocation,
// // // // //                                        GVariant *parameters,
// // // // //                                        struct endpoint_ctx *ctx)
// // // // // {
// // // // //     const char *transport;
// // // // //     g_variant_get(parameters, "(&o)", &transport);

// // // // //     g_message("[Endpoint %s] ClearConfiguration transport=%s",
// // // // //               ctx->path, transport);

// // // // //     if (ctx->transport_path &&
// // // // //         g_strcmp0(ctx->transport_path, transport) == 0) {
// // // // //         g_free(ctx->transport_path);
// // // // //         ctx->transport_path = NULL;
// // // // //     }

// // // // //     g_clear_pointer(&ctx->codec_config, g_variant_unref);
// // // // //     g_clear_pointer(&ctx->qos, g_variant_unref);

// // // // //     g_dbus_method_invocation_return_value(invocation, NULL);
// // // // // }




// // // // static void handle_clear_configuration(GDBusMethodInvocation *invocation,
// // // //                                        struct endpoint_ctx *ctx)
// // // // {
// // // //     g_message("[Endpoint %s] ClearConfiguration", ctx->path);

// // // //     g_clear_pointer(&ctx->transport_path, g_free);
// // // //     g_clear_pointer(&ctx->codec_config, g_variant_unref);
// // // //     g_clear_pointer(&ctx->qos, g_variant_unref);

// // // //     g_dbus_method_invocation_return_value(invocation, NULL);
// // // // }




// // // // /* ---------------------------------------------------- */
// // // // /* Release                                              */
// // // // /* ---------------------------------------------------- */

// // // // static void handle_release(GDBusMethodInvocation *invocation,
// // // //                            struct endpoint_ctx *ctx)
// // // // {
// // // //     g_message("[Endpoint %s] Release", ctx->path);

// // // //     g_clear_pointer(&ctx->transport_path, g_free);
// // // //     g_clear_pointer(&ctx->codec_config, g_variant_unref);
// // // //     g_clear_pointer(&ctx->qos, g_variant_unref);

// // // //     g_dbus_method_invocation_return_value(invocation, NULL);
// // // // }

// // // // // static void handle_release(GDBusMethodInvocation *invocation,
// // // // //                            struct endpoint_ctx *ctx)
// // // // // {
// // // // //     g_message("[Endpoint %s] Release", ctx->path);
// // // // //     g_dbus_method_invocation_return_value(invocation, NULL);
// // // // // }


// // // // /* ---------------------------------------------------- */
// // // // /* Method dispatcher (FIXED routing!)                   */
// // // // /* ---------------------------------------------------- */

// // // // static void method_call_cb(GDBusConnection *conn,
// // // //                            const char *sender,
// // // //                            const char *path,
// // // //                            const char *iface,
// // // //                            const char *method,
// // // //                            GVariant *params,
// // // //                            GDBusMethodInvocation *inv,
// // // //                            void *userdata)
// // // // {
// // // //     (void)conn;
// // // //      (void)sender;
// // // //      (void)path;
// // // //      (void)iface;
// // // //      (void)userdata;
// // // //     struct endpoint_ctx *ctx = NULL;

// // // //     if (g_strcmp0(path, EP_PATH_SOURCE) == 0)
// // // //         ctx = &ep_source;
// // // //     else if (g_strcmp0(path, EP_PATH_SINK) == 0)
// // // //         ctx = &ep_sink;
// // // //     else {
// // // //         g_dbus_method_invocation_return_error(
// // // //             inv, G_DBUS_ERROR, G_DBUS_ERROR_FAILED,
// // // //             "Unknown endpoint path");
// // // //         return;
// // // //     }

// // // //     if (g_strcmp0(method, "SelectProperties") == 0)
// // // //         handle_select_properties(inv, params, ctx);
// // // //     else if (g_strcmp0(method, "SetConfiguration") == 0)
// // // //         handle_set_configuration(inv, params, ctx);
// // // //     else if (g_strcmp0(method, "ClearConfiguration") == 0)
// // // //         handle_clear_configuration(inv, ctx);
// // // //     else if (g_strcmp0(method, "Release") == 0)
// // // //         handle_release(inv,ctx);
// // // //     else
// // // //         g_dbus_method_invocation_return_error(
// // // //             inv, G_DBUS_ERROR, G_DBUS_ERROR_UNKNOWN_METHOD,
// // // //             "Unknown method %s", method);
// // // // }

// // // // /* ---------------------------------------------------- */
// // // // /* Export endpoints                                     */
// // // // /* ---------------------------------------------------- */

// // // // int media_endpoint_export(GDBusConnection *conn)
// // // // {
// // // //     GDBusNodeInfo *node;
// // // //     GError *err = NULL;

// // // //     node = g_dbus_node_info_new_for_xml(endpoint_xml, &err);
// // // //     if (!node) {
// // // //         g_printerr("XML parse error: %s\n", err->message);
// // // //         g_error_free(err);
// // // //         return -1;
// // // //     }

// // // //     if (!g_dbus_connection_register_object(
// // // //             conn, EP_PATH_SOURCE,
// // // //             node->interfaces[0],
// // // //             &(GDBusInterfaceVTable){ .method_call = method_call_cb },
// // // //             NULL, NULL, &err)) {
// // // //         g_printerr("Failed to export source endpoint: %s\n", err->message);
// // // //         return -1;
// // // //     }

// // // //     if (!g_dbus_connection_register_object(
// // // //             conn, EP_PATH_SINK,
// // // //             node->interfaces[0],
// // // //             &(GDBusInterfaceVTable){ .method_call = method_call_cb },
// // // //             NULL, NULL, &err)) {
// // // //         g_printerr("Failed to export sink endpoint: %s\n", err->message);
// // // //         return -1;
// // // //     }

// // // //     g_message("[Endpoint] MediaEndpoint1 exported (source + sink)");
// // // //     return 0;
// // // // }





// // //////////////////////////Harish working until select properties/////////////////////////////


#include "bluez-media-endpoint.h"
#include <gio/gio.h>
#include <string.h>
#include <stdint.h>

#define EP_PATH_SOURCE "/local/endpoint/ep0"
#define EP_PATH_SINK   "/local/endpoint/ep1"

struct endpoint_ctx {
    const char *path;
    char *transport_path;
    GVariant *codec_config;
    GVariant *qos;
};

static struct endpoint_ctx ep_source = { .path = EP_PATH_SOURCE };
static struct endpoint_ctx ep_sink   = { .path = EP_PATH_SINK };

static const char endpoint_xml[] =
"<node>"
" <interface name='org.bluez.MediaEndpoint1'>"
"  <method name='SelectProperties'>"
"   <arg name='caps' type='a{sv}' direction='in'/>"
"   <arg name='properties' type='a{sv}' direction='out'/>"
"  </method>"
"  <method name='SetConfiguration'>"
"   <arg name='transport' type='o' direction='in'/>"
"   <arg name='properties' type='a{sv}' direction='in'/>"
"  </method>"
"  <method name='ClearConfiguration'>"
"   <arg name='transport' type='o' direction='in'/>"
"  </method>"
"  <method name='Release'/>"
" </interface>"
"</node>";

/* ---------------------------------------------------- */
/* SelectProperties – FIXED (16_2_1 preset)              */
/* ---------------------------------------------------- */
static void handle_select_properties(GDBusMethodInvocation *invocation,
                                     GVariant *parameters,
                                     struct endpoint_ctx *ctx)
{
    GVariant *caps;
    g_variant_get(parameters, "(@a{sv})", &caps);

    g_message("[Endpoint %s] SelectProperties", ctx->path);

    /* LC3 preset: 16 kHz, 7.5 ms, mono, 40 octets (16_2_1) */
    // static const uint8_t lc3_config[] = {
    //     0x02, 0x01, 0x04,        /* Sampling Frequency = 16 kHz */
    //     0x02, 0x02, 0x01,        /* Frame Duration = 7.5 ms */
    //     0x02, 0x03, 0x01,        /* Channel Count = 1 */
    //     0x03, 0x04, 0x28, 0x00   /* Frame Length = 40 bytes */
    // };

    // static const uint8_t lc3_config[] = {
    //     0x02, 0x01, 0x03,      /* Sampling Frequency = 16 kHz */
    //     0x02, 0x02, 0x02,      /* Frame Duration = 10 ms */
    //     0x02, 0x03, 0x01,      /* Channel Count = 1 */
    //     0x03, 0x04, 0x28, 0x00 /* Frame Length = 40 octets */
    // };
    static const uint8_t lc3_config[] = {
    0x02, 0x01, 0x80,        /* Sampling Frequency = 48 kHz */
    0x02, 0x02, 0x02,        /* Frame Duration = 10 ms */
    0x02, 0x03, 0x01,        /* Channel Count = 1 */
    0x03, 0x04, 0x78, 0x00   /* Frame Length = 120 octets */
};

    GVariantBuilder props;
    g_variant_builder_init(&props, G_VARIANT_TYPE("a{sv}"));

    g_variant_builder_add(&props, "{sv}",
        "Codec", g_variant_new_byte(0x06)); /* LC3 */

    // g_variant_builder_add(&props, "{sv}",
    //     "CodecConfiguration",
    //     g_variant_new_fixed_array(G_VARIANT_TYPE_BYTE,
    //                               lc3_config,
    //                               sizeof(lc3_config),
    //                               1));  //1 change

        g_variant_builder_add(&props, "{sv}", "CodecConfiguration",
        g_variant_new_fixed_array(G_VARIANT_TYPE_BYTE,
                                  lc3_config,
                                  sizeof(lc3_config),
                                  sizeof(uint8_t)));

    g_variant_builder_add(&props, "{sv}",
        "AudioLocations", g_variant_new_uint32(0x00000001));

    /* QoS — BlueZ-compliant (NO Framing key!) */
    GVariantBuilder qos;
    g_variant_builder_init(&qos, G_VARIANT_TYPE("a{sv}"));

    g_variant_builder_add(&qos, "{sv}",
        "PHY", g_variant_new_byte(2)); /* 2M */

    g_variant_builder_add(&qos, "{sv}",
        "Interval", g_variant_new_uint32(10000)); /* 10 ms */

    g_variant_builder_add(&qos, "{sv}",
        "SDU", g_variant_new_uint16(120));
    
    // guint16 sdu = 40;
    // g_variant_builder_add(&qos, "{sv}",
    // "SDU",
    // g_variant_new_fixed_array(G_VARIANT_TYPE_UINT16,
    //                           &sdu, 1, sizeof(guint16)));


    g_variant_builder_add(&qos, "{sv}",
        "Retransmissions", g_variant_new_byte(2));

    g_variant_builder_add(&qos, "{sv}",
        "Latency", g_variant_new_uint16(20));

    g_variant_builder_add(&qos, "{sv}",
        "TargetLatency", g_variant_new_byte(1)); /* balanced */

    // g_variant_builder_add(&qos, "{sv}",
    // "TargetLatency", g_variant_new_uint32(1));


    g_variant_builder_add(&props, "{sv}",
        "QoS", g_variant_builder_end(&qos));

    g_dbus_method_invocation_return_value(
        invocation,
        g_variant_new("(@a{sv})", g_variant_builder_end(&props)));

    g_variant_unref(caps);
}




// // // /* ---------------------------------------------------- */
// // // /* SetConfiguration                                     */
// // // /* ---------------------------------------------------- */
static void handle_set_configuration(GDBusMethodInvocation *invocation,
                                     GVariant *parameters,
                                     struct endpoint_ctx *ctx)
{
    const char *transport;
    GVariant *props;

    g_variant_get(parameters, "(&o@a{sv})", &transport, &props);

    g_message("[Endpoint %s] SetConfiguration", ctx->path);
    g_message("  Transport: %s", transport);

    g_free(ctx->transport_path);
    ctx->transport_path = g_strdup(transport);

    g_clear_pointer(&ctx->codec_config, g_variant_unref);
    g_variant_lookup(props, "CodecConfiguration", "@ay", &ctx->codec_config);

    g_clear_pointer(&ctx->qos, g_variant_unref);
    g_variant_lookup(props, "QoS", "@a{sv}", &ctx->qos);

    g_dbus_method_invocation_return_value(invocation, NULL);
    g_variant_unref(props);
}

static void handle_clear_configuration(GDBusMethodInvocation *invocation,
                                       struct endpoint_ctx *ctx)
{
    g_clear_pointer(&ctx->transport_path, g_free);
    g_clear_pointer(&ctx->codec_config, g_variant_unref);
    g_clear_pointer(&ctx->qos, g_variant_unref);
    g_dbus_method_invocation_return_value(invocation, NULL);
}

static void handle_release(GDBusMethodInvocation *invocation,
                           struct endpoint_ctx *ctx)
{
    g_dbus_method_invocation_return_value(invocation, NULL);
}

static void method_call_cb(GDBusConnection *conn,
                           const char *sender,
                           const char *path,
                           const char *iface,
                           const char *method,
                           GVariant *params,
                           GDBusMethodInvocation *inv,
                           void *userdata)
{
    (void)conn; (void)sender; (void)iface; (void)userdata;
    struct endpoint_ctx *ctx =
        g_strcmp0(path, EP_PATH_SOURCE) == 0 ? &ep_source : &ep_sink;

    if (!strcmp(method, "SelectProperties"))
        handle_select_properties(inv, params, ctx);
    else if (!strcmp(method, "SetConfiguration"))
        handle_set_configuration(inv, params, ctx);
    else if (!strcmp(method, "ClearConfiguration"))
        handle_clear_configuration(inv, ctx);
    else if (!strcmp(method, "Release"))
        handle_release(inv, ctx);
}



// int media_endpoint_export(GDBusConnection *conn)
// {
//     GError *err = NULL;
//     GDBusNodeInfo *node =
//         g_dbus_node_info_new_for_xml(endpoint_xml, &err);

//     g_dbus_connection_register_object(
//         conn, EP_PATH_SOURCE, node->interfaces[0],
//         &(GDBusInterfaceVTable){ .method_call = method_call_cb },
//         NULL, NULL, NULL);

//     g_dbus_connection_register_object(
//         conn, EP_PATH_SINK, node->interfaces[0],
//         &(GDBusInterfaceVTable){ .method_call = method_call_cb },
//         NULL, NULL, NULL);

//     return 0;
// }


int media_endpoint_export(GDBusConnection *conn)
{
    GError *err = NULL;
    GDBusNodeInfo *node = g_dbus_node_info_new_for_xml(endpoint_xml, &err);

    g_dbus_connection_register_object(
        conn, EP_PATH_SOURCE, node->interfaces[0],
        &(GDBusInterfaceVTable){ .method_call = method_call_cb },
        NULL, NULL, &err);

    g_dbus_connection_register_object(
        conn, EP_PATH_SINK, node->interfaces[0],
        &(GDBusInterfaceVTable){ .method_call = method_call_cb },
        NULL, NULL, &err);

    if (err) {
        g_printerr("Failed to register endpoint: %s\n", err->message);
        g_error_free(err);
        return -1;
    }
g_dbus_node_info_unref(node);
    return 0;
}


// //////////////for configuration//////////////////////////********** */
// #include "bluez-media-endpoint.h"
// #include <gio/gio.h>
// #include <string.h>
// #include <stdint.h>

// #define EP_PATH_SOURCE "/local/endpoint/ep0"
// #define EP_PATH_SINK   "/local/endpoint/ep1"

// struct endpoint_ctx {
//     const char *path;
//     char *transport_path;
//     GVariant *codec_config;
//     GVariant *qos;
// };

// static struct endpoint_ctx ep_source = { .path = EP_PATH_SOURCE };
// static struct endpoint_ctx ep_sink   = { .path = EP_PATH_SINK };

// static const char endpoint_xml[] =
// "<node>"
// " <interface name='org.bluez.MediaEndpoint1'>"
// "  <method name='SelectProperties'>"
// "   <arg name='caps' type='a{sv}' direction='in'/>"
// "   <arg name='properties' type='a{sv}' direction='out'/>"
// "  </method>"
// "  <method name='SetConfiguration'>"
// "   <arg name='transport' type='o' direction='in'/>"
// "   <arg name='properties' type='a{sv}' direction='in'/>"
// "  </method>"
// "  <method name='ClearConfiguration'>"
// "   <arg name='transport' type='o' direction='in'/>"
// "  </method>"
// "  <method name='Release'/>"
// " </interface>"
// "</node>";

// /* ---------------------------------------------------- */
// /* SelectProperties – LC3 16 kHz, 10 ms, mono, 40 bytes */
// /* ---------------------------------------------------- */
// static void handle_select_properties(GDBusMethodInvocation *invocation,
//                                      GVariant *parameters,
//                                      struct endpoint_ctx *ctx)
// {
//     GVariant *caps;
//     g_variant_get(parameters, "(@a{sv})", &caps);

//     g_message("[Endpoint %s] SelectProperties", ctx->path);
// static const uint8_t lc3_codec_config_48k[] = {
// 	0x02, 0x01, 0x80, 0x00,   /* Sampling Frequency = 48 kHz */
// 	0x02, 0x02, 0x01,        /* Frame Duration = 10 ms */
// 	0x02, 0x03, 0x01,        /* Channel Count = 1 */
// 	0x05, 0x04,              /* Frame Length (set at runtime) */
// 		0x00, 0x00,           /* min */
// 		0x00, 0x00,           /* max */
// 	0x02, 0x05, 0x01         /* Max SDU = 1 */
// };


//     GVariantBuilder props;
//     g_variant_builder_init(&props, G_VARIANT_TYPE("a{sv}"));

//     g_variant_builder_add(&props, "{sv}",
//         "Codec", g_variant_new_byte(0x06)); /* LC3 */

//     g_variant_builder_add(&props, "{sv}",
//         "CodecConfiguration",
//         g_variant_new_fixed_array(G_VARIANT_TYPE_BYTE,
//                                   lc3_config,
//                                   sizeof(lc3_config),
//                                   1));

//     g_variant_builder_add(&props, "{sv}",
//         "AudioLocations", g_variant_new_uint32(0x00000001)); /* Front Left */

//     /* QoS dictionary */
//     GVariantBuilder qos;
//     g_variant_builder_init(&qos, G_VARIANT_TYPE("a{sv}"));

//     g_variant_builder_add(&qos, "{sv}",
//         "PHY", g_variant_new_byte(0x02));           /* LE 2M */
//     g_variant_builder_add(&qos, "{sv}",
//         "Interval", g_variant_new_uint32(10000));   /* 10 ms */
//     g_variant_builder_add(&qos, "{sv}",
//         "SDU", g_variant_new_uint16(40));           /* matches frame length */
//     g_variant_builder_add(&qos, "{sv}",
//         "Retransmissions", g_variant_new_byte(2));
//     g_variant_builder_add(&qos, "{sv}",
//         "Latency", g_variant_new_uint16(20));
//     g_variant_builder_add(&qos, "{sv}",
//         "TargetLatency", g_variant_new_byte(0x01)); /* balanced */

//     g_variant_builder_add(&props, "{sv}",
//         "QoS", g_variant_builder_end(&qos));

//     g_dbus_method_invocation_return_value(
//         invocation,
//         g_variant_new("(@a{sv})", g_variant_builder_end(&props)));

//     g_variant_unref(caps);
// }

// /* ---------------------------------------------------- */
// /* SetConfiguration                                     */
// /* ---------------------------------------------------- */
// static void handle_set_configuration(GDBusMethodInvocation *invocation,
//                                      GVariant *parameters,
//                                      struct endpoint_ctx *ctx)
// {
//     const char *transport;
//     GVariant *props;

//     g_variant_get(parameters, "(&o@a{sv})", &transport, &props);

//     g_message("[Endpoint %s] SetConfiguration", ctx->path);
//     g_message("  Transport: %s", transport);

//     g_free(ctx->transport_path);
//     ctx->transport_path = g_strdup(transport);

//     g_clear_pointer(&ctx->codec_config, g_variant_unref);
//     g_variant_lookup(props, "CodecConfiguration", "@ay", &ctx->codec_config);

//     g_clear_pointer(&ctx->qos, g_variant_unref);
//     g_variant_lookup(props, "QoS", "@a{sv}", &ctx->qos);

//     g_dbus_method_invocation_return_value(invocation, NULL);
//     g_variant_unref(props);
// }

// /* ---------------------------------------------------- */
// /* ClearConfiguration                                   */
// /* ---------------------------------------------------- */
// static void handle_clear_configuration(GDBusMethodInvocation *invocation,
//                                        struct endpoint_ctx *ctx)
// {
//     g_clear_pointer(&ctx->transport_path, g_free);
//     g_clear_pointer(&ctx->codec_config, g_variant_unref);
//     g_clear_pointer(&ctx->qos, g_variant_unref);
//     g_dbus_method_invocation_return_value(invocation, NULL);
// }

// /* ---------------------------------------------------- */
// /* Release                                              */
// /* ---------------------------------------------------- */
// static void handle_release(GDBusMethodInvocation *invocation,
//                            struct endpoint_ctx *ctx)
// {
//     (void)ctx;
//     g_dbus_method_invocation_return_value(invocation, NULL);
// }

// /* ---------------------------------------------------- */
// /* Dispatcher                                           */
// /* ---------------------------------------------------- */
// static void method_call_cb(GDBusConnection *conn,
//                            const char *sender,
//                            const char *path,
//                            const char *iface,
//                            const char *method,
//                            GVariant *params,
//                            GDBusMethodInvocation *inv,
//                            void *userdata)
// {
//     (void)conn;
//     (void)sender;
//     (void)iface;
//     (void)userdata;

//     struct endpoint_ctx *ctx =
//         g_strcmp0(path, EP_PATH_SOURCE) == 0 ? &ep_source : &ep_sink;

//     if (!strcmp(method, "SelectProperties"))
//         handle_select_properties(inv, params, ctx);
//     else if (!strcmp(method, "SetConfiguration"))
//         handle_set_configuration(inv, params, ctx);
//     else if (!strcmp(method, "ClearConfiguration"))
//         handle_clear_configuration(inv, ctx);
//     else if (!strcmp(method, "Release"))
//         handle_release(inv, ctx);
// }

// /* ---------------------------------------------------- */
// /* Export endpoints                                     */
// /* ---------------------------------------------------- */
// int media_endpoint_export(GDBusConnection *conn)
// {
//     GError *err = NULL;
//     GDBusNodeInfo *node =
//         g_dbus_node_info_new_for_xml(endpoint_xml, &err);

//     if (!node) {
//         g_printerr("Endpoint XML error: %s\n", err->message);
//         g_error_free(err);
//         return -1;
//     }

//     g_dbus_connection_register_object(
//         conn, EP_PATH_SOURCE, node->interfaces[0],
//         &(GDBusInterfaceVTable){ .method_call = method_call_cb },
//         NULL, NULL, NULL);

//     g_dbus_connection_register_object(
//         conn, EP_PATH_SINK, node->interfaces[0],
//         &(GDBusInterfaceVTable){ .method_call = method_call_cb },
//         NULL, NULL, NULL);

//     g_dbus_node_info_unref(node);
//     return 0;
// }






/////////////////////////////////chandu working last ///////////////////////////////
// // ////////////////////////////////auto-selection code////////////////////////////

// #include "bluez-media-endpoint.h"
// #include <gio/gio.h>
// #include <string.h>
// #include <stdint.h>

// #define EP_PATH_SOURCE "/local/endpoint/ep0"
// #define EP_PATH_SINK   "/local/endpoint/ep1"

// #define LC3_CODEC_ID 0x06

// struct endpoint_ctx {
//     const char *path;
// };

// static struct endpoint_ctx ep_source = { .path = EP_PATH_SOURCE };
// static struct endpoint_ctx ep_sink   = { .path = EP_PATH_SINK };

// static const char endpoint_xml[] =
// "<node>"
// " <interface name='org.bluez.MediaEndpoint1'>"
// "  <method name='SelectProperties'>"
// "   <arg name='caps' type='a{sv}' direction='in'/>"
// "   <arg name='properties' type='a{sv}' direction='out'/>"
// "  </method>"
// "  <method name='SetConfiguration'>"
// "   <arg name='transport' type='o' direction='in'/>"
// "   <arg name='properties' type='a{sv}' direction='in'/>"
// "  </method>"
// "  <method name='ClearConfiguration'>"
// "   <arg name='transport' type='o' direction='in'/>"
// "  </method>"
// "  <method name='Release'/>"
// " </interface>"
// "</node>";

// /* ---------------------------------------------------- */
// /* LC3 auto-selection helper                            */
// /* ---------------------------------------------------- */
// static void build_lc3_codec_config(uint8_t *cfg, size_t *len,
//                                    uint16_t frame_len)
// {
//     uint8_t *p = cfg;

//     /* Sampling Frequency = 48 kHz */
//     *p++ = 0x02; *p++ = 0x01; *p++ = 0x80; *p++ = 0x00;

//     /* Frame Duration = 10 ms */
//     *p++ = 0x02; *p++ = 0x02; *p++ = 0x02;

//     /* Channel Count = 1 */
//     *p++ = 0x02; *p++ = 0x03; *p++ = 0x01;

//     /* Frame Length (exact value) */
//     *p++ = 0x05; *p++ = 0x04;
//     *p++ = frame_len & 0xff;
//     *p++ = frame_len >> 8;
//     *p++ = frame_len & 0xff;
//     *p++ = frame_len >> 8;

//     /* Max SDU = 1 */
//     *p++ = 0x02; *p++ = 0x05; *p++ = 0x01;

//     *len = p - cfg;
// }

// /* ---------------------------------------------------- */
// /* SelectProperties – AUTO SELECTION                    */
// /* ---------------------------------------------------- */
// static void handle_select_properties(GDBusMethodInvocation *invocation,
//                                      GVariant *parameters,
//                                      struct endpoint_ctx *ctx)
// {
//     GVariant *caps;
//     g_variant_get(parameters, "(@a{sv})", &caps);

//     uint16_t min_fl = 0, max_fl = 0;

//     /* Parse Frame Length from PAC */
//     GVariant *cc = g_variant_lookup_value(caps, "CodecCapabilities",
//                                           G_VARIANT_TYPE("ay"));
//     if (cc) {
//         const uint8_t *d;
//         size_t len;
//         d = g_variant_get_fixed_array(cc, &len, 1);

//         for (size_t i = 0; i + 1 < len;) {
//             uint8_t l = d[i];
//             uint8_t t = d[i + 1];

//             if (t == 0x04 && l == 0x05) { /* Frame Length */
//                 min_fl = d[i + 2] | (d[i + 3] << 8);
//                 max_fl = d[i + 4] | (d[i + 5] << 8);
//                 break;
//             }
//             i += l + 1;
//         }
//         g_variant_unref(cc);
//     }

//     if (!max_fl)
//         max_fl = 155; /* safe fallback */

//     uint8_t codec_cfg[32];
//     size_t codec_len;

//     build_lc3_codec_config(codec_cfg, &codec_len, max_fl);

//     GVariantBuilder props;
//     g_variant_builder_init(&props, G_VARIANT_TYPE("a{sv}"));

//     g_variant_builder_add(&props, "{sv}",
//         "Codec", g_variant_new_byte(LC3_CODEC_ID));

//     g_variant_builder_add(&props, "{sv}",
//         "CodecConfiguration",
//         g_variant_new_fixed_array(G_VARIANT_TYPE_BYTE,
//                                   codec_cfg, codec_len, 1));

//     g_variant_builder_add(&props, "{sv}",
//         "AudioLocations", g_variant_new_uint32(0x00000001));

//     /* QoS */
//     GVariantBuilder qos;
//     g_variant_builder_init(&qos, G_VARIANT_TYPE("a{sv}"));

//     g_variant_builder_add(&qos, "{sv}",
//         "Interval", g_variant_new_uint32(10000));
//     // g_variant_builder_add(&qos, "{sv}",
//     //     "SDU", g_variant_new_uint16(max_fl));
// uint16_t sdu = max_fl + 4;

// g_variant_builder_add(&qos, "{sv}",
//     "SDU", g_variant_new_uint16(sdu));



//     g_variant_builder_add(&qos, "{sv}",
//         "PHY", g_variant_new_byte(0x02));
//     g_variant_builder_add(&qos, "{sv}",
//         "Retransmissions", g_variant_new_byte(2));
//     g_variant_builder_add(&qos, "{sv}",
//         "Latency", g_variant_new_uint16(20));

//     g_variant_builder_add(&props, "{sv}",
//         "QoS", g_variant_builder_end(&qos));

//     g_dbus_method_invocation_return_value(
//         invocation,
//         g_variant_new("(@a{sv})",
//             g_variant_builder_end(&props)));

//     g_variant_unref(caps);
// }

// /* ---------------------------------------------------- */
// /* Boilerplate handlers                                 */
// /* ---------------------------------------------------- */
// static void handle_set_configuration(GDBusMethodInvocation *invocation,
//                                      GVariant *parameters,
//                                      struct endpoint_ctx *ctx)
// {
//     g_dbus_method_invocation_return_value(invocation, NULL);
// }

// static void handle_clear_configuration(GDBusMethodInvocation *invocation,
//                                        struct endpoint_ctx *ctx)
// {
//     g_dbus_method_invocation_return_value(invocation, NULL);
// }

// static void handle_release(GDBusMethodInvocation *invocation,
//                            struct endpoint_ctx *ctx)
// {
//     g_dbus_method_invocation_return_value(invocation, NULL);
// }

// static void method_call_cb(GDBusConnection *conn,
//                            const char *sender,
//                            const char *path,
//                            const char *iface,
//                            const char *method,
//                            GVariant *params,
//                            GDBusMethodInvocation *inv,
//                            void *userdata)
// {
//     struct endpoint_ctx *ctx =
//         strcmp(path, EP_PATH_SOURCE) == 0 ? &ep_source : &ep_sink;

//     if (!strcmp(method, "SelectProperties"))
//         handle_select_properties(inv, params, ctx);
//     else if (!strcmp(method, "SetConfiguration"))
//         handle_set_configuration(inv, params, ctx);
//     else if (!strcmp(method, "ClearConfiguration"))
//         handle_clear_configuration(inv, ctx);
//     else if (!strcmp(method, "Release"))
//         handle_release(inv, ctx);
// }

// int media_endpoint_export(GDBusConnection *conn)
// {
//     GDBusNodeInfo *node =
//         g_dbus_node_info_new_for_xml(endpoint_xml, NULL);

//     g_dbus_connection_register_object(
//         conn, EP_PATH_SOURCE, node->interfaces[0],
//         &(GDBusInterfaceVTable){ .method_call = method_call_cb },
//         NULL, NULL, NULL);

//     g_dbus_connection_register_object(
//         conn, EP_PATH_SINK, node->interfaces[0],
//         &(GDBusInterfaceVTable){ .method_call = method_call_cb },
//         NULL, NULL, NULL);

//     g_dbus_node_info_unref(node);
//     return 0;
// }








