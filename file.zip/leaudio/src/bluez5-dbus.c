

// ///////////////working///////////////////////////

#include "bluez5-dbus.h"
#include <gio/gio.h>
#include <stdio.h>
#include <stdint.h>

/* BlueZ constants */
#define BLUEZ_SERVICE "org.bluez"
#define MEDIA_PATH    "/org/bluez/hci0"
#define MEDIA_IFACE   "org.bluez.Media1"

/* Endpoint paths */
#define EP_SOURCE_PATH "/local/endpoint/ep0"
#define EP_SINK_PATH   "/local/endpoint/ep1"

/* LE Audio UUIDs */
#define UUID_PAC_SOURCE "00002bc9-0000-1000-8000-00805f9b34fb"
#define UUID_PAC_SINK   "00002bcb-0000-1000-8000-00805f9b34fb"

/* Full LC3 capabilities */
static const uint8_t lc3_caps[] = {
    0x03, 0x01, 0xff, 0x00,
    0x02, 0x02,
    0x03, 0x02,
    0x03, 0x03,
    0x05, 0x04,
    0x1e, 0x00,
    0xf0, 0x00
};

static void register_endpoint(GDBusConnection *conn,
                              const char *path,
                              const char *uuid)
{
    GVariantBuilder b;
    GVariant *props;
    GError *err = NULL;

    g_variant_builder_init(&b, G_VARIANT_TYPE("a{sv}"));

    g_variant_builder_add(&b, "{sv}",
        "UUID", g_variant_new_string(uuid));

    g_variant_builder_add(&b, "{sv}",
        "Codec", g_variant_new_byte(0x06));

    g_variant_builder_add(&b, "{sv}",
        "Capabilities",
        g_variant_new_fixed_array(G_VARIANT_TYPE_BYTE,
                                  lc3_caps,
                                  sizeof(lc3_caps),
                                  sizeof(uint8_t)));

    props = g_variant_builder_end(&b);

    g_dbus_connection_call_sync(
        conn,
        BLUEZ_SERVICE,
        MEDIA_PATH,
        MEDIA_IFACE,
        "RegisterEndpoint",
        g_variant_new("(o@a{sv})", path, props),
        NULL, G_DBUS_CALL_FLAGS_NONE,
        -1, NULL, &err);

    if (err) {
        g_printerr("RegisterEndpoint failed: %s\n", err->message);
        g_error_free(err);
    } else {
        g_print("[BlueZ] Registered %s (%s)\n", path, uuid);
    }
}

void bluez_register_endpoints(GDBusConnection *conn)
{
    register_endpoint(conn, EP_SOURCE_PATH, UUID_PAC_SOURCE);
    register_endpoint(conn, EP_SINK_PATH,   UUID_PAC_SINK);
}




