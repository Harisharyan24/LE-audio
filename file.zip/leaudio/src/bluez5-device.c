// // // #include <stdio.h>
// // // #include <stdlib.h>
// // // #include <string.h>
// // // #include <stdbool.h>

// // // #include <gio/gio.h>

// // // #include "bluez-device.h"
// // // // #include "bluez-dbus.h"
// // // #include "iso-io.h"
// // // #include "bap-codec-lc3.h"

// // // /* ---------------- device state ---------------- */

// // // struct le_device {
// // //     GDBusConnection *bus;
// // //     char *path;

// // //     int iso_fd;

// // //     struct lc3_codec *codec;
// // //     struct spa_bt_iso_io iso;
// // // };

// // // static struct le_device dev;

// // // /* ---------------- ISO callback ---------------- */

// // // static void iso_pull_cb(struct spa_bt_iso_io *io)
// // // {
// // //     struct lc3_codec *codec = io->codec_data;
// // //     int32_t *pcm = io->user_data;
// // //     size_t encoded;

// // //     memset(pcm, 0, bap_lc3_get_pcm_bytes(codec));

// // //     if (lc3_codec_encode(codec,
// // //                          pcm,
// // //                          bap_lc3_get_pcm_bytes(codec),
// // //                          io->buf,
// // //                          sizeof(io->buf),
// // //                          &encoded) < 0) {
// // //         fprintf(stderr, "[ISO] encode failed\n");
// // //         return;
// // //     }

// // //     io->size = encoded;
// // //     io->timestamp++;

// // //     fprintf(stderr, "[ISO] encoded %zu bytes\n", encoded);
// // // }

// // // /* ---------------- transport handler ---------------- */

// // // static void on_transport_added(const char *path, GVariant *props)
// // // {
// // //     GVariant *fd_v;
// // //     int fd;

// // //     fd_v = g_variant_lookup_value(props, "IsoSocket",
// // //                                   G_VARIANT_TYPE_HANDLE);
// // //     if (!fd_v)
// // //         return;

// // //     fd = g_variant_get_handle(fd_v);
// // //     g_variant_unref(fd_v);

// // //     fprintf(stderr, "[BAP] ISO transport fd=%d\n", fd);

// // //     dev.iso_fd = fd;

// // //     dev.codec = lc3_codec_create(48000, 1, 10000, 60);
// // //     if (!dev.codec) {
// // //         fprintf(stderr, "LC3 init failed\n");
// // //         return;
// // //     }

// // //     memset(&dev.iso, 0, sizeof(dev.iso));
// // //     dev.iso.codec_data = dev.codec;

// // //     dev.iso.user_data = calloc(1, bap_lc3_get_pcm_bytes(dev.codec));
// // //     dev.iso.duration = 10000 * 1000;

// // //     spa_bt_iso_io_set_cb(&dev.iso, iso_pull_cb, dev.iso.user_data);

// // //     fprintf(stderr, "[BAP] ISO pipeline ready\n");
// // // }

// // // /* ---------------- InterfacesAdded ---------------- */

// // // static void on_interfaces_added(const char *path, GVariant *ifaces)
// // // {
// // //     GVariantIter iter;
// // //     const char *iface;
// // //     GVariant *props;

// // //     g_variant_iter_init(&iter, ifaces);
// // //     while (g_variant_iter_next(&iter, "{&s@a{sv}}", &iface, &props)) {

// // //         if (strcmp(iface, "org.bluez.Device1") == 0) {
// // //             dev.path = strdup(path);
// // //             fprintf(stderr, "[BlueZ] device %s\n", path);
// // //         }

// // //         if (strcmp(iface, "org.bluez.MediaTransport1") == 0) {
// // //             on_transport_added(path, props);
// // //         }

// // //         g_variant_unref(props);
// // //     }
// // // }

// // // /* ---------------- DBus signal ---------------- */

// // // static void on_dbus_signal(GDBusConnection *conn,
// // //                            const char *sender,
// // //                            const char *path,
// // //                            const char *iface,
// // //                            const char *signal,
// // //                            GVariant *params,
// // //                            void *userdata)
// // // {
// // //     if (strcmp(signal, "InterfacesAdded") == 0) {
// // //         const char *obj;
// // //         GVariant *ifaces;

// // //         g_variant_get(params, "(&o@a{sa{sv}})", &obj, &ifaces);
// // //         on_interfaces_added(obj, ifaces);
// // //         g_variant_unref(ifaces);
// // //     }
// // // }

// // // /* ---------------- public API ---------------- */

// // // int bluez_device_init(GDBusConnection *bus)
// // // {
// // //     memset(&dev, 0, sizeof(dev));
// // //     dev.bus = bus;

// // //     g_dbus_connection_signal_subscribe(
// // //         bus,
// // //         "org.bluez",
// // //         "org.freedesktop.DBus.ObjectManager",
// // //         "InterfacesAdded",
// // //         NULL,
// // //         NULL,
// // //         G_DBUS_SIGNAL_FLAGS_NONE,
// // //         on_dbus_signal,
// // //         NULL,
// // //         NULL);

// // //     fprintf(stderr, "[BlueZ] device handler ready\n");
// // //     return 0;
// // // }

// // // void bluez_device_cleanup(void)
// // // {
// // //     free(dev.iso.user_data);
// // //     if (dev.codec)
// // //         lc3_codec_destroy(dev.codec);
// // //     free(dev.path);
// // // }



// // // #include <stdio.h>
// // // #include <stdlib.h>
// // // #include <string.h>
// // // #include <stdbool.h>

// // // #include <gio/gio.h>

// // // #include "bluez-device.h"
// // // #include "iso-io.h"
// // // #include "bap-codec-lc3.h"

// // // /* ------------------------------------------------ */
// // // /* Device state                                     */
// // // /* ------------------------------------------------ */

// // // struct le_device {
// // //     GDBusConnection *bus;
// // //     char *path;

// // //     int iso_fd;

// // //     struct lc3_codec *codec;
// // //     struct spa_bt_iso_io iso;
// // // };

// // // static struct le_device dev;

// // // /* ------------------------------------------------ */
// // // /* ISO callback (still dummy, but wired correctly) */
// // // /* ------------------------------------------------ */

// // // static void iso_pull_cb(struct spa_bt_iso_io *io)
// // // {
// // //     struct lc3_codec *codec = io->codec_data;
// // //     int32_t *pcm = io->user_data;
// // //     size_t encoded;

// // //     memset(pcm, 0, bap_lc3_get_pcm_bytes(codec));

// // //     if (lc3_codec_encode(codec,
// // //                          pcm,
// // //                          bap_lc3_get_pcm_bytes(codec),
// // //                          io->buf,
// // //                          sizeof(io->buf),
// // //                          &encoded) < 0) {
// // //         fprintf(stderr, "[ISO] encode failed\n");
// // //         return;
// // //     }

// // //     io->size = encoded;
// // //     io->timestamp++;

// // //     fprintf(stderr, "[ISO] encoded %zu bytes\n", encoded);
// // // }

// // // /* ------------------------------------------------ */
// // // /* BAP Stream handling (THIS IS NEW)                */
// // // /* ------------------------------------------------ */

// // // static void handle_bap_stream(const char *path, GVariant *props)
// // // {
// // //     GVariant *v;
// // //     int fd;

// // //     fprintf(stderr, "[BAP] Stream object: %s\n", path);

// // //     v = g_variant_lookup_value(props, "IsoSocket",
// // //                                G_VARIANT_TYPE_HANDLE);
// // //     if (!v) {
// // //         fprintf(stderr, "[BAP] IsoSocket not present yet\n");
// // //         return;
// // //     }

// // //     fd = g_variant_get_handle(v);
// // //     g_variant_unref(v);

// // //     fprintf(stderr, "[BAP] ISO socket received fd=%d\n", fd);
// // //     dev.iso_fd = fd;

// // //     /* Create LC3 codec */
// // //     dev.codec = lc3_codec_create(48000, 1, 10000, 60);
// // //     if (!dev.codec) {
// // //         fprintf(stderr, "LC3 init failed\n");
// // //         return;
// // //     }

// // //     memset(&dev.iso, 0, sizeof(dev.iso));
// // //     dev.iso.codec_data = dev.codec;
// // //     dev.iso.user_data = calloc(1, bap_lc3_get_pcm_bytes(dev.codec));
// // //     dev.iso.duration  = 10000 * 1000;

// // //     spa_bt_iso_io_set_cb(&dev.iso, iso_pull_cb, dev.iso.user_data);

// // //     fprintf(stderr, "[BAP] ISO pipeline ready\n");
// // // }

// // // /* ------------------------------------------------ */
// // // /* Endpoint registration                             */
// // // /* ------------------------------------------------ */

// // // static void handle_bap_endpoint(const char *path, GVariant *props)
// // // {
// // //     GVariant *v;
// // //     const char *direction;

// // //     fprintf(stderr, "[BAP] Endpoint found: %s\n", path);

// // //     v = g_variant_lookup_value(props, "Direction", G_VARIANT_TYPE_STRING);
// // //     if (v) {
// // //         direction = g_variant_get_string(v, NULL);
// // //         fprintf(stderr, "[BAP] Endpoint direction: %s\n", direction);
// // //         g_variant_unref(v);
// // //     }

// // //     /* For simplicity, just print codec capabilities */
// // //     v = g_variant_lookup_value(props, "CodecCapabilities", G_VARIANT_TYPE_ARRAY);
// // //     if (v) {
// // //         fprintf(stderr, "[BAP] Endpoint has CodecCapabilities\n");
// // //         g_variant_unref(v);
// // //     }

// // //     /* Here you could implement actual endpoint registration / connect */
// // // }


// // // /* ------------------------------------------------ */
// // // /* InterfacesAdded handler                          */
// // // /* ------------------------------------------------ */

// // // static void on_interfaces_added(const char *path, GVariant *ifaces)
// // // {
// // //     GVariantIter iter;
// // //     const char *iface;
// // //     GVariant *props;

// // //     g_variant_iter_init(&iter, ifaces);
// // //     while (g_variant_iter_next(&iter, "{&s@a{sv}}", &iface, &props)) {

// // //         if (strcmp(iface, "org.bluez.Device1") == 0) {
// // //             dev.path = strdup(path);
// // //             fprintf(stderr, "[BlueZ] device %s\n", path);
// // //         }

// // //         else if (strcmp(iface, "org.bluez.BapEndpoint1") == 0) {
// // //             fprintf(stderr, "[BAP] Endpoint available: %s\n", path);
// // //         }

// // //         else if (strcmp(iface, "org.bluez.BapStream1") == 0) {
// // //             handle_bap_stream(path, props);
// // //         }

// // //         g_variant_unref(props);
// // //     }
// // // }

// // // /* ------------------------------------------------ */
// // // /* D-Bus signal handler                             */
// // // /* ------------------------------------------------ */

// // // // static void on_dbus_signal(GDBusConnection *conn __attribute__((unused)),
// // // //                            const char *sender __attribute__((unused)),
// // // //                            const char *path __attribute__((unused)),
// // // //                            const char *iface __attribute__((unused)),
// // // //                            const char *signal,
// // // //                            GVariant *params,
// // // //                            void *userdata __attribute__((unused)))

// // // // {
// // // //     if (strcmp(signal, "InterfacesAdded") == 0) {
// // // //         const char *obj;
// // // //         GVariant *ifaces;

// // // //         g_variant_get(params, "(&o@a{sa{sv}})", &obj, &ifaces);
// // // //         on_interfaces_added(obj, ifaces);
// // // //         g_variant_unref(ifaces);
// // // //     }
// // // // }

// // // static void on_dbus_signal(GDBusConnection *conn,
// // //                            const char *sender,
// // //                            const char *path,
// // //                            const char *iface,
// // //                            const char *signal,
// // //                            GVariant *params,
// // //                            void *userdata)
// // // {
// // //     (void)conn;
// // //     (void)sender;
// // //     (void)path;
// // //     (void)iface;
// // //     (void)userdata;

// // //     if (strcmp(signal, "InterfacesAdded") == 0) {
// // //         const char *obj;
// // //         GVariant *ifaces;

// // //         g_variant_get(params, "(&o@a{sa{sv}})", &obj, &ifaces);
// // //         on_interfaces_added(obj, ifaces);
// // //         g_variant_unref(ifaces);
// // //     }
// // // }



// // // /* ------------------------------------------------ */
// // // /* Public API                                      */
// // // /* ------------------------------------------------ */

// // // int bluez_device_init(GDBusConnection *bus)
// // // {
// // //     memset(&dev, 0, sizeof(dev));
// // //     dev.bus = bus;

// // //     g_dbus_connection_signal_subscribe(
// // //         bus,
// // //         "org.bluez",
// // //         "org.freedesktop.DBus.ObjectManager",
// // //         "InterfacesAdded",
// // //         NULL,
// // //         NULL,
// // //         G_DBUS_SIGNAL_FLAGS_NONE,
// // //         on_dbus_signal,
// // //         NULL,
// // //         NULL);

// // //     fprintf(stderr, "[BlueZ] device handler ready\n");
// // //     return 0;
// // // }

// // // void bluez_device_cleanup(void)
// // // {
// // //     free(dev.iso.user_data);
// // //     if (dev.codec)
// // //         lc3_codec_destroy(dev.codec);
// // //     free(dev.path);
// // // }


// // #include <stdio.h>
// // #include <stdlib.h>
// // #include <string.h>
// // #include <stdbool.h>

// // #include <gio/gio.h>

// // #include "bluez-device.h"
// // #include "iso-io.h"
// // #include "bap-codec-lc3.h"

// // /* ------------------------------------------------ */
// // /* Device state                                     */
// // /* ------------------------------------------------ */

// // struct le_device {
// //     GDBusConnection *bus;
// //     char *path;

// //     int iso_fd;

// //     struct lc3_codec *codec;
// //     struct spa_bt_iso_io iso;
// // };

// // static struct le_device dev;

// // /* ------------------------------------------------ */
// // /* ISO callback (still dummy, but wired correctly) */
// // /* ------------------------------------------------ */

// // static void iso_pull_cb(struct spa_bt_iso_io *io)
// // {
// //     struct lc3_codec *codec = io->codec_data;
// //     int32_t *pcm = io->user_data;
// //     size_t encoded;

// //     memset(pcm, 0, bap_lc3_get_pcm_bytes(codec));

// //     if (lc3_codec_encode(codec,
// //                          pcm,
// //                          bap_lc3_get_pcm_bytes(codec),
// //                          io->buf,
// //                          sizeof(io->buf),
// //                          &encoded) < 0) {
// //         fprintf(stderr, "[ISO] encode failed\n");
// //         return;
// //     }

// //     io->size = encoded;
// //     io->timestamp++;

// //     fprintf(stderr, "[ISO] encoded %zu bytes\n", encoded);
// // }

// // /* ------------------------------------------------ */
// // /* BAP Stream handling                              */
// // /* ------------------------------------------------ */

// // static void handle_bap_stream(const char *path, GVariant *props)
// // {
// //     GVariant *v;
// //     int fd;

// //     fprintf(stderr, "[BAP] Stream object: %s\n", path);

// //     v = g_variant_lookup_value(props, "IsoSocket",
// //                                G_VARIANT_TYPE_HANDLE);
// //     if (!v) {
// //         fprintf(stderr, "[BAP] IsoSocket not present yet\n");
// //         return;
// //     }

// //     fd = g_variant_get_handle(v);
// //     g_variant_unref(v);

// //     fprintf(stderr, "[BAP] ISO socket received fd=%d\n", fd);
// //     dev.iso_fd = fd;

// //     /* Create LC3 codec */
// //     dev.codec = lc3_codec_create(48000, 1, 10000, 60);
// //     if (!dev.codec) {
// //         fprintf(stderr, "LC3 init failed\n");
// //         return;
// //     }

// //     memset(&dev.iso, 0, sizeof(dev.iso));
// //     dev.iso.codec_data = dev.codec;
// //     dev.iso.user_data = calloc(1, bap_lc3_get_pcm_bytes(dev.codec));
// //     dev.iso.duration  = 10000 * 1000;

// //     spa_bt_iso_io_set_cb(&dev.iso, iso_pull_cb, dev.iso.user_data);

// //     fprintf(stderr, "[BAP] ISO pipeline ready\n");
// // }

// // /* ------------------------------------------------ */
// // /* Endpoint registration                             */
// // /* ------------------------------------------------ */

// // #define LE_SINK_PATH "/org/bluez/endpoint/sink"
// // #define LE_SOURCE_PATH "/org/bluez/endpoint/source"

// // static const guint8 lc3_sink_cap[] = {
// //     0x06,       /* Codec ID: LC3 (0x06) */
// //     0x00, 0x02, /* Frame duration: 7.5 ms, 10 ms (example) */
// //     0x00, 0x01, /* Channel allocation: Stereo */
// //     0x40,       /* Octets per frame: 64 (example) */
// // };

// // static const guint8 lc3_source_cap[] = {
// //     0x06,
// //     0x00, 0x02,
// //     0x00, 0x01,
// //     0x40,
// // };

// // /* Helper: register endpoint over D-Bus */
// // // static void register_endpoint(GDBusConnection *conn, const char *path,
// // //                               const guint8 *cap, gsize cap_len)
// // // {
// // //     GError *error = NULL;
// // //     GVariantBuilder props_builder;
// // //     GVariant *props;
// // //     GVariant *parameters;

// // //     // Initialize builder for a{sv}
// // //     g_variant_builder_init(&props_builder, G_VARIANT_TYPE("a{sv}"));

// // //     // Add UUID property
// // //     g_variant_builder_add(&props_builder, "{sv}", "UUID",
// // //                           g_variant_new_string("0000184E-0000-1000-8000-00805f9b34fb"));

// // //     // Add CodecId property
// // //     g_variant_builder_add(&props_builder, "{sv}", "CodecId",
// // //                           g_variant_new_byte(cap[0]));

// // //     // Add Capabilities property (skip first byte which is CodecId)
// // //     g_variant_builder_add(&props_builder, "{sv}", "Capabilities",
// // //                           g_variant_new_fixed_array(G_VARIANT_TYPE_BYTE,
// // //                                                     &cap[1],
// // //                                                     cap_len - 1,
// // //                                                     sizeof(guint8)));

// // //     // Finalize the builder into a GVariant
// // //     props = g_variant_builder_end(&props_builder);

// // //     // Wrap parameters for RegisterEndpoint call: (o a{sv})
// // //     parameters = g_variant_new("(oa{sv})", path, props);

// // //     // Synchronous DBus call
// // //     g_dbus_connection_call_sync(conn,
// // //                                 "org.bluez",               // bus name
// // //                                 "/org/bluez",              // object path
// // //                                 "org.bluez.Media1",        // interface
// // //                                 "RegisterEndpoint",        // method
// // //                                 parameters,                // parameters
// // //                                 NULL,                      // expected reply type (NULL = any)
// // //                                 G_DBUS_CALL_FLAGS_NONE,
// // //                                 -1,                        // timeout msec (-1 = default)
// // //                                 NULL,                      // cancellable
// // //                                 &error);                   // error

// // //     if (error) {
// // //         g_printerr("Failed to register endpoint %s: %s\n", path, error->message);
// // //         g_clear_error(&error);
// // //     } else {
// // //         g_print("[BlueZ] Endpoint registered: %s\n", path);
// // //     }
// // // }

// // void register_endpoint_with_bluez(GDBusConnection *conn) {
// //     GError *error = NULL;
// //     GVariantBuilder builder;
// //     GVariant *params;
// //     GDBusProxy *proxy;

// //     proxy = g_dbus_proxy_new_sync(conn,
// //                                   G_DBUS_PROXY_FLAGS_NONE,
// //                                   NULL,
// //                                   BLUEZ_BUS,
// //                                   ADAPTER_OBJ,
// //                                   MEDIA_INTERFACE,
// //                                   NULL,
// //                                   &error);
// //     if (!proxy) {
// //         g_printerr("[LEAUDIO] Failed to create proxy: %s\n", error->message);
// //         g_error_free(error);
// //         return;
// //     }

// //     g_variant_builder_init(&builder, G_VARIANT_TYPE("a{sv}"));
// //     g_variant_builder_add(&builder, "{sv}", "UUID",
// //                           g_variant_new_string("00001812-0000-1000-8000-00805f9b34fb"));
// //     g_variant_builder_add(&builder, "{sv}", "Codec",
// //                           g_variant_new_byte(0x06));
// //     g_variant_builder_add(&builder, "{sv}", "Capabilities",
// //                           g_variant_new("ay", lc3_caps, sizeof(lc3_caps)));
// //     g_variant_builder_add(&builder, "{sv}", "DelayReporting",
// //                           g_variant_new_boolean(FALSE));

// //     params = g_variant_new("(oa{sv})", ENDPOINT_PATH, g_variant_builder_end(&builder));

// //     g_print("[LEAUDIO] Calling BlueZ RegisterEndpoint\n");

// //     g_dbus_proxy_call_sync(proxy,
// //                            "RegisterEndpoint",
// //                            params,
// //                            G_DBUS_CALL_FLAGS_NONE,
// //                            -1,
// //                            NULL,
// //                            &error);

// //     if (error) {
// //         g_printerr("[LEAUDIO ERROR] RegisterEndpoint failed: %s\n", error->message);
// //         g_error_free(error);
// //     } else {
// //         g_print("[LEAUDIO] Endpoint registered with BlueZ successfully\n");
// //     }

// //     g_object_unref(proxy);
// // }




// // static void register_le_audio_endpoints(GDBusConnection *conn)
// // {
// //     /* Sink (playback) endpoint */
// //     register_endpoint(conn, LE_SINK_PATH, lc3_sink_cap, sizeof(lc3_sink_cap));

// //     /* Source (capture) endpoint */
// //     register_endpoint(conn, LE_SOURCE_PATH, lc3_source_cap, sizeof(lc3_source_cap));
// // }

// // static void handle_bap_endpoint(const char *path, GVariant *props)
// // {
// //     GVariant *v;
// //     const char *direction;

// //     fprintf(stderr, "[BAP] Endpoint found: %s\n", path);

// //     v = g_variant_lookup_value(props, "Direction", G_VARIANT_TYPE_STRING);
// //     if (v) {
// //         direction = g_variant_get_string(v, NULL);
// //         fprintf(stderr, "[BAP] Endpoint direction: %s\n", direction);
// //         g_variant_unref(v);
// //     }

// //     v = g_variant_lookup_value(props, "CodecCapabilities", G_VARIANT_TYPE_ARRAY);
// //     if (v) {
// //         fprintf(stderr, "[BAP] Endpoint has CodecCapabilities\n");
// //         g_variant_unref(v);
// //     }
// // }

// // /* ------------------------------------------------ */
// // /* InterfacesAdded handler                          */
// // /* ------------------------------------------------ */

// // static void on_interfaces_added(const char *path, GVariant *ifaces)
// // {
// //     GVariantIter iter;
// //     const char *iface;
// //     GVariant *props;

// //     g_variant_iter_init(&iter, ifaces);
// //     while (g_variant_iter_next(&iter, "{&s@a{sv}}", &iface, &props)) {

// //         if (strcmp(iface, "org.bluez.Device1") == 0) {
// //             dev.path = strdup(path);
// //             fprintf(stderr, "[BlueZ] device %s\n", path);
// //         }

// //         else if (strcmp(iface, "org.bluez.BapEndpoint1") == 0) {
// //             fprintf(stderr, "[BAP] Endpoint available: %s\n", path);
// //             handle_bap_endpoint(path, props);
// //         }

// //         else if (strcmp(iface, "org.bluez.BapStream1") == 0) {
// //             handle_bap_stream(path, props);
// //         }

// //         g_variant_unref(props);
// //     }
// // }

// // /* ------------------------------------------------ */
// // /* D-Bus signal handler                             */
// // /* ------------------------------------------------ */

// // static void on_dbus_signal(GDBusConnection *conn,
// //                            const char *sender,
// //                            const char *path,
// //                            const char *iface,
// //                            const char *signal,
// //                            GVariant *params,
// //                            void *userdata)
// // {
// //     (void)conn;
// //     (void)sender;
// //     (void)path;
// //     (void)iface;
// //     (void)userdata;

// //     if (strcmp(signal, "InterfacesAdded") == 0) {
// //         const char *obj;
// //         GVariant *ifaces;

// //         g_variant_get(params, "(&o@a{sa{sv}})", &obj, &ifaces);
// //         on_interfaces_added(obj, ifaces);
// //         g_variant_unref(ifaces);
// //     }
// // }

// // /* ------------------------------------------------ */
// // /* Public API                                      */
// // /* ------------------------------------------------ */

// // int bluez_device_init(GDBusConnection *bus)
// // {
// //     memset(&dev, 0, sizeof(dev));
// //     dev.bus = bus;

// //     g_dbus_connection_signal_subscribe(
// //         bus,
// //         "org.bluez",
// //         "org.freedesktop.DBus.ObjectManager",
// //         "InterfacesAdded",
// //         NULL,
// //         NULL,
// //         G_DBUS_SIGNAL_FLAGS_NONE,
// //         on_dbus_signal,
// //         NULL,
// //         NULL);

// //     fprintf(stderr, "[BlueZ] device handler ready\n");

// //     /* Register LE Audio endpoints immediately */
// //     register_le_audio_endpoints(bus);

// //     return 0;
// // }

// // void bluez_device_cleanup(void)
// // {
// //     free(dev.iso.user_data);
// //     if (dev.codec)
// //         lc3_codec_destroy(dev.codec);
// //     free(dev.path);
// // }


// // // #changes
// // // #include "bluez5-dbus.h"
// // // #include <gio/gio.h>
// // // #include <stdio.h>

// // // // Example device registration flow
// // // void register_le_audio_endpoints(GDBusConnection *conn) {
// // //     // Register the endpoint object
// // //     register_endpoint_object(conn);

// // //     // Call BlueZ RegisterEndpoint
// // //     register_endpoint_with_bluez(conn);
// // // }

// // // // Device-specific code continues below
// // // void connect_device(const char *dev_path) {
// // //     // Code to connect LE Audio device
// // //     printf("[DEVICE] Connecting to device %s\n", dev_path);
// // //     // Actual connection logic here
// // // }


// #include "bluez5-dbus.h"
// #include <gio/gio.h>
// #include <stdio.h>

// // Example device registration flow
// void register_le_audio_endpoints(GDBusConnection *conn) {
//     // Call the new unified endpoint registration function
//     // register_endpoints(conn);

//     register_le_audio_endpoints(conn);


// }

// // Device-specific code continues below
// void connect_device(const char *dev_path) {
//     // Code to connect LE Audio device
//     printf("[DEVICE] Connecting to device %s\n", dev_path);
//     // Actual connection logic here
// }

#include "bluez-device.h"
#include "bluez-media-endpoint.h"
#include "bluez5-dbus.h"
#include <stdio.h>

int bluez_device_init(GDBusConnection *conn)
{
    (void)conn;

    printf("[BlueZ] device handler ready\n");

    // media_endpoint_register(conn);
    // bluez_register_endpoint(conn);

    return 0;
}

void bluez_device_cleanup(void)
{
}
