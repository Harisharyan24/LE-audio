#ifndef ISO_IO_H
#define ISO_IO_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

/* Forward declarations (opaque types) */
struct spa_bt_transport;
struct spa_bt_decode_buffer;

/* ISO I/O object */
struct spa_bt_iso_io {
	uint64_t now;        /* next packet time (ns) */
	uint64_t duration;   /* ISO interval (ns) */

	bool resync;

	uint32_t timestamp;
	uint8_t buf[4096];
	size_t size;
	bool need_resync;

	void *codec_data;
	void *user_data;
};

/* Pull callback */
typedef void (*spa_bt_iso_io_pull_t)(struct spa_bt_iso_io *io);

/* API */
struct spa_bt_iso_io *
spa_bt_iso_io_create(struct spa_bt_transport *t);

struct spa_bt_iso_io *
spa_bt_iso_io_attach(struct spa_bt_iso_io *io,
                     struct spa_bt_transport *t);

void spa_bt_iso_io_destroy(struct spa_bt_iso_io *io);

void spa_bt_iso_io_set_cb(struct spa_bt_iso_io *io,
                          spa_bt_iso_io_pull_t pull,
                          void *user_data);

/* RX helpers */
void spa_bt_iso_io_set_source_buffer(struct spa_bt_iso_io *io,
                                     struct spa_bt_decode_buffer *buffer);

int64_t spa_bt_iso_io_recv(struct spa_bt_iso_io *io, int64_t now);

void spa_bt_iso_io_check_rx_sync(struct spa_bt_iso_io *io,
                                 uint64_t position);

#endif /* ISO_IO_H */

