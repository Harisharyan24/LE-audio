// #pragma once
// #include <gio/gio.h>

// #define LEAUDIO_ENDPOINT_PATH "/org/leaudio/endpoint0"

// void media_endpoint_register(GDBusConnection *conn);

#pragma once
#include <gio/gio.h>

/* Export MediaEndpoint1 objects */
int media_endpoint_export(GDBusConnection *conn);
