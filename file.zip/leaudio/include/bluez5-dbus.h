// // #ifndef BLUEZ5_DBUS_H
// // #define BLUEZ5_DBUS_H

// // #include <gio/gio.h>

// // #define BLUEZ_BUS "org.bluez"
// // #define ADAPTER_OBJ "/org/bluez/hci0"
// // #define MEDIA_INTERFACE "org.bluez.Media1"
// // #define ENDPOINT_PATH "/local/endpoint/ep0"

// // extern const guint8 lc3_caps[];
// // extern const size_t lc3_caps_size;

// // void register_endpoint_object(GDBusConnection *conn);
// // void register_endpoint_with_bluez(GDBusConnection *conn);

// // #endif /* BLUEZ5_DBUS_H */



// #ifndef BLUEZ5_DBUS_H
// #define BLUEZ5_DBUS_H

// #include <gio/gio.h>

// // This function will register all LE Audio endpoints (sink + source)
// void register_endpoints(GDBusConnection *conn);

// #endif // BLUEZ5_DBUS_H


#pragma once
#include <gio/gio.h>

void bluez_register_endpoints(GDBusConnection *conn);
